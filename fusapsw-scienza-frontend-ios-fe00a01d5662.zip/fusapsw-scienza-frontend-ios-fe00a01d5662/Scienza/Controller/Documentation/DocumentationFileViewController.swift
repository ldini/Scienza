//
//  DocumentationFileViewController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/20/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration
import SVProgressHUD
import SDWebImage


class DocumentationFileViewController: UIViewController, UIWebViewDelegate {
    
    @IBOutlet var webView: UIWebView!
    
    var file: DocumentationFile!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateModel()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func populateModel() {
        SVProgressHUD.show()
        webView.delegate = self
        self.webView.loadRequest(URLRequest(url: URL(string: self.file.file!)!))
    }
   
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        SVProgressHUD.dismiss()
    }
}
