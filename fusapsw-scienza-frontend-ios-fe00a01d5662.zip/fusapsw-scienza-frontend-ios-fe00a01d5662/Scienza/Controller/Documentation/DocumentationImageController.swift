//
//  DocumentationImageController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/16/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class DocumentationImageController: UIViewController {
    
    @IBOutlet var count: UILabel!
    @IBOutlet var collectionView: UICollectionView!
    
    var type: String!
    var imageList: [DocumentationImage]! = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.count.text = "\(self.imageList.count) Imágenes"
        self.collectionView.reloadData()
    }
    
    func insertImage(image: DocumentationImage) {
        self.imageList.insert(image, at: 0)
        self.count.text = "\(self.imageList.count) Imágenes"
        self.collectionView.insertItems(at: [IndexPath(item: 0, section: 0)])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "imageViewSegue" {
            let cell = sender as! DocumentationImageCell
            let indexPath = self.collectionView!.indexPath(for: cell)!
            let image = self.imageList[indexPath.row]
            let destination = segue.destination as! DocumentationImageViewController
            destination.image = image
        }
    }
    
    @IBAction func uploadImage(_ sender: UIButton) {
        let alertController = UIAlertController(title: nil, message: "Subir un documento", preferredStyle: .actionSheet)
        let galleryAction = UIAlertAction(title: "Galería", style: .default) { action in self.openGallery() }
        let cameraAction = UIAlertAction(title: "Cámara", style: .default) { action in self.openCamera() }
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel) { action in }
        alertController.addAction(galleryAction)
        alertController.addAction(cameraAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true)
    }
}


extension DocumentationImageController : UICollectionViewDataSource, UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imageList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cellIdentifier = "imageCell"
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? DocumentationImageCell
        let image = self.imageList[indexPath.row]
        cell?.image.downloadFrom(link: image.smallImage!)
        cell?.date.text = image.date!
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(
            width: UIScreen.main.bounds.width * 0.4375,
            height: UIScreen.main.bounds.height * 0.3080
        )
    }
    
    func collectionView(_ collectionView: UICollectionView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, heightForItemAt indexPath: IndexPath) -> CGFloat {
        return -1
    }
    
    func collectionView(_ collectionView: UICollectionView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}


extension DocumentationImageController : UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func openGallery() {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    internal func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            let storyBoard = UIStoryboard(name: "Documentation", bundle: nil)
            let cropController = storyBoard.instantiateViewController(withIdentifier: "DocumentationCrop") as! DocumentationCropController
            cropController.type = self.type
            cropController.image = pickedImage
            picker.pushViewController(cropController, animated: true)
        }
    }
}
