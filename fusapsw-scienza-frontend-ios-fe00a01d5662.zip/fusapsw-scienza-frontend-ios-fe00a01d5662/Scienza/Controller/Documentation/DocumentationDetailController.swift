//
//  DocumentationDetailController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/15/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class DocumentationDetailController: UIViewController {
    
    @IBOutlet var titleView: UILabel!
    @IBOutlet var segmentedControl: UISegmentedControl!
    @IBOutlet var imageView: UIView!
    @IBOutlet var fileView: UIView!
    
    var type: String!
    var imageController: DocumentationImageController!
    var fileController: DocumentationFileController!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.segmentedControl.layer.borderColor = #colorLiteral(red: 0.5189305986, green: 0.0599368306, blue: 0.1109958256, alpha: 1)
        self.segmentedControl.layer.cornerRadius = 0.0
        self.segmentedControl.layer.borderWidth = 1.5
        self.segmentedControl.layer.opacity = 1.0
        self.populateModel()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func populateModel() {
        SVProgressHUD.show()
        self.titleView.text = (self.type == "PRESCRIPTION") ? "Recetas Médicas" : "Otros Estudios"
        let endpoint = (self.type == "PRESCRIPTION") ? Endpoint.documentationPrescriptionList : Endpoint.documentationOtherStudyList
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<DocumentationResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.imageController.imageList = data.body?.imageList!
                    self.imageController.populateModel()
                    self.fileController.fileList = data.body?.fileList!
                    self.fileController.populateModel()
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "imageSegue" {
            self.imageController = segue.destination as? DocumentationImageController
            self.imageController.type = self.type
        }
        if segue.identifier == "fileSegue" {
            self.fileController = segue.destination as? DocumentationFileController
            self.fileController.type = self.type
        }
    }
    
    
    @IBAction func valueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            self.imageView.isHidden = false
            self.fileView.isHidden = true
        }
        if sender.selectedSegmentIndex == 1 {
            self.imageView.isHidden = true
            self.fileView.isHidden = false
        }
    }
    
    
    @IBAction func unwindUploadImage(segue: UIStoryboardSegue!) {
        let source = segue.source as! DocumentationCropController
        self.uploadImage(image: source.compressedImage!)
    }
    
    
    @IBAction func unwindUploadFile(segue: UIStoryboardSegue!) {
        let source = segue.source as! DocumentationFileController
        self.uploadFile(fileName: source.fileName, file: source.file!)
    }
    
    
    func uploadImage(image: UIImage!) {
        SVProgressHUD.show()
        
        let data = DocumentationImageRequest()
        data.fileName = "saraza.jpg"
        data.image = "data:image/jpeg;base64," + image.jpegData(compressionQuality: 0.9)!.base64EncodedString()
        
        let endpoint = (self.type == "PRESCRIPTION") ? Endpoint.documentationPrescriptionImageCreate : Endpoint.documentationOtherStudyImageCreate
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data, timeout: 50)
        AF.request(request).responseObject { (response: DataResponse<DocumentationImageResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.uploadImage(image: image)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    let home = (SesionManager.getActiveUser()?.home)!
                    if (self.type == "PRESCRIPTION") {
                        home.prescriptionsUploaded = home.prescriptionsUploaded! + 1
                    }
                    else {
                        home.otherStudiesUploaded = home.otherStudiesUploaded! + 1
                    }
                    self.imageController.insertImage(image: data.body!)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.uploadImage(image: image)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    
    func uploadFile(fileName: String!, file: Data!) {
        SVProgressHUD.show()
        
        let data = DocumentationFileRequest()
        data.fileName = fileName
        data.file = "data:application/pdf;base64," + file.base64EncodedString()
        
        let endpoint = (self.type == "PRESCRIPTION") ? Endpoint.documentationPrescriptionFileCreate : Endpoint.documentationOtherStudyFileCreate
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data, timeout: 50)
        AF.request(request).responseObject { (response: DataResponse<DocumentationFileResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.uploadFile(fileName: fileName, file: file)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    let home = (SesionManager.getActiveUser()?.home)!
                    if (self.type == "PRESCRIPTION") {
                        home.prescriptionsUploaded = home.prescriptionsUploaded! + 1
                    }
                    else {
                        home.otherStudiesUploaded = home.otherStudiesUploaded! + 1
                    }
                    self.fileController.insertFile(file: data.body!)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.uploadFile(fileName: fileName, file: file)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}
