//
//  DocumentationController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/15/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class DocumentationController: UIViewController {
    
    @IBOutlet var countPrescription: UILabel!
    @IBOutlet var countOtherStudy: UILabel!
    @IBOutlet var buttonPrescription: UIButton!
    @IBOutlet var buttonOtherStudy: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addLayerOpacity()
        self.populateModel()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.populateModel()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func populateModel() {
        let prescriptionsUploaded = (SesionManager.getActiveUser()?.home?.prescriptionsUploaded)!
        let otherStudiesUploaded = (SesionManager.getActiveUser()?.home?.otherStudiesUploaded)!
        self.countPrescription.text = "\(prescriptionsUploaded) Fotos"
        self.countOtherStudy.text = "\(otherStudiesUploaded) Fotos"
    }
    
    
    func addLayerOpacity() {
        let coverPrescription = CALayer()
        coverPrescription.frame = CGRect(
            x: 0,
            y: 0,
            width: UIScreen.main.bounds.width,
            height: UIScreen.main.bounds.height * 0.4242
        )
        coverPrescription.backgroundColor = UIColor.black.cgColor
        coverPrescription.opacity = 0.2
        self.buttonPrescription.layer.addSublayer(coverPrescription)
        
        let coverOtherStudy = CALayer()
        coverOtherStudy.frame = CGRect(
            x: 0,
            y: 0,
            width: UIScreen.main.bounds.width,
            height: UIScreen.main.bounds.height * 0.4242
        )
        coverOtherStudy.backgroundColor = UIColor.black.cgColor
        coverOtherStudy.opacity = 0.2
        self.buttonOtherStudy.layer.addSublayer(coverOtherStudy)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "prescriptionSegue" {
            let destination = segue.destination as! DocumentationDetailController
            destination.type = "PRESCRIPTION"
        }
        if segue.identifier == "otherStudySegue" {
            let destination = segue.destination as! DocumentationDetailController
            destination.type = "OTHER_STUDY"
        }
    }
}
