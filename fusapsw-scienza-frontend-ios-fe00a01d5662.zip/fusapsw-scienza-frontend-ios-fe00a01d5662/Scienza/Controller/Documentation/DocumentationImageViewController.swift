//
//  MostrarImagenCollect.swift
//  Scienza
//
//  Created by Kender on 16/2/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration
import SVProgressHUD
import SDWebImage

class DocumentationImageViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    var image: DocumentationImage!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateModel()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func populateModel() {
        SVProgressHUD.show()
        self.imageView.downloadFrom(link: self.image.image!) { (result) in
            SVProgressHUD.dismiss()
            if(!result) {
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}
