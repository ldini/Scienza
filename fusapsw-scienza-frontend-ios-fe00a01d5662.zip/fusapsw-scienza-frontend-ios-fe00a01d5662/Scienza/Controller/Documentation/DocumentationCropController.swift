//
//  CropImagen.swift
//  Scienza
//
//  Created by Kender on 9/5/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import AKImageCropperView
import SVProgressHUD


class DocumentationCropController: UIViewController {
    
    @IBOutlet weak var btnGuardar: UIButton!
    @IBOutlet weak var btnCancelar: UIButton!
    @IBOutlet weak var cropView: AKImageCropperView!
    
    var type: String!
    var image: UIImage!
    var croppedImage: UIImage!
    var compressedImage: UIImage!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cropView.delegate = self
        cropView.image = image
        if cropView.isOverlayViewActive {
            cropView.hideOverlayView(animationDuration: 0.3)
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear, animations: {}, completion: nil)
        } else {
            cropView.showOverlayView(animationDuration: 0.3)
            UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveLinear, animations: {}, completion: nil)
        }
    }
    
    
    @IBAction func save(_ sender: Any) {
        let title = (self.type == "PRESCRIPTION") ? UIConstant.instance.uploadPrescription : UIConstant.instance.uploadOtherStudy
        let uiAlert = UIAlertController(title: "", message: title, preferredStyle: .alert)
        uiAlert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
            self.croppedImage = self.cropView.croppedImage
            self.compressedImage = self.compressImage(image: self.croppedImage)
            self.performSegue(withIdentifier: "unwindUploadImage", sender: self)
        }))
        uiAlert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: { action in }))
        self.present(uiAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func compressImage(image: UIImage) -> UIImage{
        var actualHeight : CGFloat = image.size.height
        var actualWidth : CGFloat = image.size.width
        let maxHeight : CGFloat = 800.0
        let maxWidth : CGFloat = 600.0
        var imgRatio : CGFloat = actualWidth/actualHeight
        let maxRatio : CGFloat = maxWidth/maxHeight
        
        if (actualHeight > maxHeight || actualWidth > maxWidth){
            if(imgRatio < maxRatio){
                imgRatio = maxHeight / actualHeight
                actualWidth = imgRatio * actualWidth
                actualHeight = maxHeight
            }else if(imgRatio > maxRatio){
                imgRatio = maxWidth / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = maxWidth
            }else{
                actualHeight = maxHeight
                actualWidth = maxWidth
            }
        }
        let rect = CGRect(x: 0.0, y: 0.0, width: actualWidth, height: actualHeight)
        UIGraphicsBeginImageContext(rect.size)
        image.draw(in: rect)
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return scaledImage!
    }
}


extension DocumentationCropController: AKImageCropperViewDelegate {
    
    func imageCropperViewDidChangeCropRect(view: AKImageCropperView, cropRect rect: CGRect) {}
}
