//
//  DocumentationFileController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/16/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class DocumentationFileController: UIViewController {
    
    @IBOutlet var count: UILabel!
    @IBOutlet var tableView: UITableView!
    
    var type: String!
    var fileList: [DocumentationFile]! = []
    var file: Data!
    var fileName: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.estimatedRowHeight = 50.0
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.count.text = "\(self.fileList.count) Archivos"
        self.tableView.reloadData()
    }
    
    func insertFile(file: DocumentationFile) {
        self.fileList.insert(file, at: 0)
        self.count.text = "\(self.fileList.count) Archivos"
        self.tableView.insertRows(at: [IndexPath(item: 0, section: 0)], with: .top)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "fileViewSegue" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let file = self.fileList[indexPath.row]
                let destination = segue.destination as! DocumentationFileViewController
                destination.file = file
            }
        }
    }
    
    @IBAction func uploadFile(_ sender: UIButton) {
        let alertController = UIAlertController(title: nil, message: "Subir un documento", preferredStyle: .actionSheet)
        let icloudAction = UIAlertAction(title: "iCloud Drive", style: .default) { action in self.openICloud() }
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel) { action in }
        alertController.addAction(icloudAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true)
    }
}


extension DocumentationFileController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.fileList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "fileCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? DocumentationFileCell
        let file = self.fileList[indexPath.row]
        cell?.fileName.text = file.name!
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}


extension DocumentationFileController : UINavigationControllerDelegate, UIDocumentPickerDelegate {
    
    func openICloud() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.data"], in: UIDocumentPickerMode.import)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = UIModalPresentationStyle.fullScreen
        self.present(documentPicker, animated: true, completion: nil)
    }
    
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        if controller.documentPickerMode == .import {
            let title = (self.type == "PRESCRIPTION") ? UIConstant.instance.uploadPrescription : UIConstant.instance.uploadOtherStudy
            let uiAlert = UIAlertController(title: "", message: title, preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                do {
                    let url = URL(string: url.absoluteString)
                    self.file = try Data(contentsOf: url!)
                    self.fileName = (url?.lastPathComponent)!.components(separatedBy: ".")[0] + ".pdf"
                    self.performSegue(withIdentifier: "unwindUploadFile", sender: self)
                }
                catch{
                    let alert = UIAlertController(title: "", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }))
            uiAlert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: { action in }))
            self.present(uiAlert, animated: true, completion: nil)
        }
    }
}
