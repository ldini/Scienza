//
//  File.swift
//  Scienza
//
//  Created by Kender on 6/1/17.
//  Copyright © 2017 fusap. All rights reserved.
//
import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import SideMenu
import OneSignal


class HomeController : UIViewController, OSSubscriptionObserver {
    
    @IBOutlet weak var flagQueries: UIImageView!
    @IBOutlet weak var countQueries: UILabel!
    @IBOutlet weak var flagNotifications: UIImageView!
    @IBOutlet weak var countNotifications: UILabel!
    @IBOutlet var documentationView: HomeFunctionView!
    
    var appDelegate: AppDelegate!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        self.setupNavigationBar()
        self.setupSideMenu()
        self.populateModel()
        self.setupOneSignal()
        NotificationCenter.default.addObserver(self, selector: #selector(self.populateModel), name: NSNotification.Name("ReloadHome"), object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        self.appDelegate.pubNub?.unsubscribeFromAll()
        self.populateModel()
    }
    
    func setupNavigationBar() {
        let titleImegeView = UIImageView(image: UIImage(named: "general_logo"))
        titleImegeView.frame = CGRect(x: 0, y: 0, width: 100, height: 20)
        titleImegeView.contentMode = .scaleAspectFit
        self.navigationItem.titleView = titleImegeView
        
        let menuButton = UIButton(type: .system)
        menuButton.setImage(UIImage(named: "home_hamburguer")?.withRenderingMode(.alwaysOriginal), for: .normal)
        menuButton.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        menuButton.addTarget(self, action: #selector(showSideMenu), for: .touchUpInside)
        let barButton = UIBarButtonItem(customView: menuButton)
        NSLayoutConstraint.activate([(barButton.customView!.widthAnchor.constraint(equalToConstant: 30)),(barButton.customView!.heightAnchor.constraint(equalToConstant: 30))])
        self.navigationItem.leftBarButtonItem = barButton
    }
    
    func setupSideMenu() {
        let storyboard = UIStoryboard(name: "Menu", bundle: nil)
        SideMenuManager.default.menuLeftNavigationController = storyboard.instantiateViewController(withIdentifier: "MenuNavigation") as? UISideMenuNavigationController
        
        SideMenuManager.default.menuAddPanGestureToPresent(toView: self.navigationController!.navigationBar)
        SideMenuManager.default.menuAddScreenEdgePanGesturesToPresent(toView: self.navigationController!.view)
        SideMenuManager.default.menuPresentMode = .menuSlideIn
        SideMenuManager.default.menuAnimationFadeStrength = CGFloat(0.8)
        
        let modelDevice = UIDevice.current.model
        if modelDevice == "iPhone" {
            SideMenuManager.default.menuWidth = view.frame.width * CGFloat(0.8)
        }
        else {
            SideMenuManager.default.menuWidth = view.frame.width * CGFloat(0.6)
        }
    }
    
    func setupOneSignal() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let onesignalInitSettings = [kOSSettingsKeyAutoPrompt: false, kOSSettingsKeyInAppLaunchURL: false]
        
        OneSignal.rootController = self
        OneSignal.initWithLaunchOptions(appDelegate.launchOptions,
                                        appId: HttpRequest.instance.oneSignalId,
                                        handleNotificationReceived: OneSignal.notificationReceivedBlock,
                                        handleNotificationAction: OneSignal.notificationActionBlock,
                                        settings: onesignalInitSettings)
        
        OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification;
        OneSignal.add(self as OSSubscriptionObserver)
        OneSignal.promptForPushNotifications(userResponse: { accepted in
            print("OneSignal Result Acceptance: \(accepted)")
            if accepted {
                let data = OneSignalRequest()
                data.playerId = OneSignal.getPermissionSubscriptionState().subscriptionStatus.userId
                let endpoint = Endpoint.updatePlayerId
                let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
                AF.request(request).responseObject { (response: DataResponse<Response>) in
                    switch response.result {
                    case let .success(data):
                        print("OneSignal Result: \((data.header?.code)!)")
                        break
                    case .failure:
                        break
                    }
                }
            }
        })
    }
    
    func onOSSubscriptionChanged(_ stateChanges: OSSubscriptionStateChanges!) {
        if !stateChanges.from.subscribed && stateChanges.to.subscribed {
            print("Subscribed for OneSignal push notifications!")
        }
        if let playerId = stateChanges.to.userId {
            let data = OneSignalRequest()
            data.playerId = playerId
            let endpoint = Endpoint.updatePlayerId
            let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
            AF.request(request).responseObject { (response: DataResponse<Response>) in
                switch response.result {
                case let .success(data):
                    print("OneSignal Result: \((data.header?.code)!)")
                    break
                case .failure:
                    break
                }
            }
        }
    }
    
    @objc func showSideMenu() {
        self.present(SideMenuManager.default.menuLeftNavigationController!, animated: true, completion: nil)
    }
    
    @objc func populateModel(){
        SesionManager.getActiveUser()?.home(completion: { (home) in
            if let home = home {
                self.documentationView.isHidden = !(home.allowUploadDocumentation!)
                if home.unreadQueries! > 0 {
                    self.flagQueries.isHidden = false
                    self.countQueries.text = String(home.unreadQueries!)
                    self.countQueries.isHidden = false
                }
                else {
                    self.flagQueries.isHidden = true
                    self.countQueries.isHidden = true
                    self.countQueries.text = String(0)
                }
                if home.unreadNotifications! > 0 {
                    self.flagNotifications.isHidden = false
                    self.countNotifications.text = String(home.unreadNotifications!)
                    self.countNotifications.isHidden = false
                }
                else {
                    self.flagNotifications.isHidden = true
                    self.countNotifications.isHidden = true
                    self.countNotifications.text = String(0)
                }
            }
        })
    }
    
    @IBAction func unwindHome(segue: UIStoryboardSegue!) {
        self.navigationController?.isNavigationBarHidden = false
        self.populateModel()
    }
    
    @IBAction func unwindHomeToLogin(segue: UIStoryboardSegue!) {
        SideMenuManager.default.menuLeftNavigationController?.dismiss(animated: true, completion: {
            let endpoint = Endpoint.logout
            let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: Request())
            AF.request(request).responseObject { (response: DataResponse<Response>) in
                SesionManager.closeSession()
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let loginController = storyboard.instantiateViewController(withIdentifier: "LoginNavigation") as? UINavigationController
                UIApplication.setRootView(loginController!, options: UIApplication.logoutAnimation)
            }
        })
    }
}
