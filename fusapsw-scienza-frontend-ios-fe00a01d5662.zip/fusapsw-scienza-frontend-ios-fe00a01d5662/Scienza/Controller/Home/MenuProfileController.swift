//
//  MenuProfileController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/30/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class MenuProfileController : UIViewController {
    
    
    @IBOutlet var tableView: UITableView!
    
    var users: [User] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.populateModel()
    }
    
    func populateModel() {
        self.users = SesionManager.getUsers()
        self.tableView.reloadData()
    }
    
    func changeAffiliate(user: User!) {
        SesionManager.changeUser(user: user)
        self.performSegue(withIdentifier: "unwindHome", sender: nil)
    }
    
    @objc func unbind(button: UIButton) {
        let userDeleted = self.users[button.tag]
        let alert = UIAlertController(
            title: "",
            message: "¿Está seguro que desea desvincular el afiliado \(userDeleted.firstName) \(userDeleted.lastName)?",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertAction.Style.default, handler: nil))
        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in self.unbindAffiliate(userDeleted: userDeleted)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func unbindAffiliate(userDeleted: User!) {
        /* Fuerzo a que se envie por el usuario principal */
        let token = SesionManager.getToken()!
        let user = SesionManager.getConfiguration()?.user!
        let data = UnbindAffiliateRequest()
        data.sapId = userDeleted?.sapId
        
        SVProgressHUD.show()
        let endpoint = Endpoint.unbindAffiliate
        let request = HttpRequest.instance.createPostRequest(
            endpoint: endpoint,
            data: data,
            token: token,
            user: user,
            timeout: nil
        )
        AF.request(request).responseObject { (response: DataResponse<Response>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.unbindAffiliate(userDeleted: userDeleted)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    SesionManager.changeUser(user: user!)
                    SesionManager.removeUser(user: userDeleted)
                    self.performSegue(withIdentifier: "unwindHome", sender: nil)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.unbindAffiliate(userDeleted: userDeleted)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}


extension MenuProfileController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
            case 0:
                return 1
            default:
                return self.users.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cellIdentifier = "menuAddProfileCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MenuAddProfileCell
            return cell!
        default:
            let user = self.users[indexPath.row]
            let cellIdentifier = "menuProfileCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MenuProfileCell
            cell?.avatar.image = user.avatarAsImage()
            cell?.fullName.text = "\(user.firstName) \(user.lastName)"
            cell?.documentNumber.text = "DNI \(user.documentNumber)"
            cell?.btnDelete.isHidden = (user == SesionManager.getConfiguration()?.user!)
            cell?.btnDelete.tag = indexPath.row
            cell?.btnDelete.addTarget(self, action: #selector(unbind), for: .touchUpInside)
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 0:
            self.performSegue(withIdentifier: "bindAffiliateSegue", sender: nil)
        default:
            let user = self.users[indexPath.row]
            self.changeAffiliate(user: user)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
