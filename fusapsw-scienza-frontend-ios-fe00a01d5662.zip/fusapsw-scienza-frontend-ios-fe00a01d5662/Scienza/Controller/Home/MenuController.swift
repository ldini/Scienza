//
//  SideMenuController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/20/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import SideMenu


class MenuController : UIViewController {

    @IBOutlet var menuPrincipal: UIView!
    @IBOutlet var menuInformation: UIView!
    @IBOutlet var menuProfile: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupNavigationBar()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.menuPrincipal.isHidden = false
        self.menuInformation.isHidden = true
        self.menuProfile.isHidden = true
    }
    
    func setupNavigationBar() {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func unwindMenuPrincipal(segue: UIStoryboardSegue!) {
        self.menuPrincipal.isHidden = false
        self.menuInformation.isHidden = true
        self.menuProfile.isHidden = true
    }
    
    @IBAction func unwindMenuInformation(segue: UIStoryboardSegue!) {
        self.menuPrincipal.isHidden = true
        self.menuInformation.isHidden = false
        self.menuProfile.isHidden = true
    }
    
    @IBAction func unwindMenuProfile(segue: UIStoryboardSegue!) {
        self.menuPrincipal.isHidden = true
        self.menuInformation.isHidden = true
        self.menuProfile.isHidden = false
    }
}
