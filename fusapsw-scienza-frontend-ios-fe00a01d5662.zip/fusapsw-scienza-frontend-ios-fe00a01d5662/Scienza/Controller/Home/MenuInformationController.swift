//
//  MenuInformacionController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/29/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit


class MenuInformationController : UIViewController {
    
    
    @IBOutlet var tableView: UITableView!
    
    var functionality: [(String, String, Int)] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.populateModel()
    }
    
    func populateModel() {
        self.functionality = []
        self.functionality.append(("Preguntas Frecuentes", "faqSegue", 0))
        self.functionality.append(("Términos y condiciones", "termsAndConditionSegue", 0))
        self.functionality.append(("Versión", "versionSegue", 0))
    }
}


extension MenuInformationController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.functionality.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let functionality = self.functionality[indexPath.row]
        let cellIdentifier = "menuFunctionalityCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MenuFunctionalityCell
        cell?.functionality.text = functionality.0
        cell?.count.text = String(functionality.2)
        cell?.count.isHidden = functionality.2 == 0
        cell?.count.layer.cornerRadius = 12.0
        cell?.count.layer.masksToBounds = true
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let functionality = self.functionality[indexPath.row]
        self.performSegue(withIdentifier: functionality.1, sender: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
