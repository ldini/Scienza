//
//  QueryDetailController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/26/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import PubNub


class QueryChatController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var input: UITextField!
    @IBOutlet var btnSend: UIButton!
    
    var queryId: Int!
    var queryDetail: QueryDetail?
    var messages: [QueryMessage]! = []
    var footer: String?
    var appDelegate: AppDelegate!
    
    let backend: String = "99999999-9999-9999-9999-999999999999"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.input.delegate = self
        self.input.isEnabled = false
        self.btnSend.isEnabled = false
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        let viewControllers = self.navigationController?.viewControllers.filter{(x) -> Bool in !x.isKind(of: QueryCreateController.self)}
        self.navigationController?.setViewControllers(viewControllers!, animated: true)
        NotificationCenter.default.addObserver(self, selector: #selector(self.reloadData(_:)), name: NSNotification.Name("ReloadQueryChat"), object: nil)
        
        let backIcon = UIButton(type: .system)
        backIcon.setImage(UIImage(named: "general_back")?.withRenderingMode(.alwaysOriginal), for: .normal)
        backIcon.frame = CGRect(x: 0, y: 0, width: 20, height: 34)
        backIcon.addTarget(self, action: #selector(backAction), for: .touchUpInside)
        let adminIcon = UIButton(type: .system)
        adminIcon.setImage(UIImage(named: "query_admin")?.withRenderingMode(.alwaysOriginal), for: .normal)
        adminIcon.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        self.navigationItem.leftBarButtonItems = [UIBarButtonItem(customView: backIcon), UIBarButtonItem(customView: adminIcon)]
        
        self.populateModel()
    }

    @objc func reloadData(_ notification: Notification?) {
        self.populateModel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.appDelegate.pubNub?.removeListener(self)
    }
    
    @objc func backAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func populateModel() {
        SVProgressHUD.show()
        let endpoint = String(format: Endpoint.queryDetail, self.queryId)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<QueryDetailResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.populateModel()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.queryDetail = data.body!
                    self.messages = self.queryDetail?.messages
                    self.footer = self.queryDetail?.footerDescription
                    
                    self.navigationItem.setTitle(
                        title: "#" + (self.queryDetail?.ticket)!,
                        subtitle: (self.queryDetail?.toolbarDescription)!
                    )
                    
                    self.tableView.reloadData()
                    self.tableView.layoutIfNeeded()
                    let row = (self.footer == nil) ? self.messages.count-1 : 0
                    let section = (self.footer == nil) ? 0 : 1
                    let indexPath = IndexPath(row: row, section: section)
                    self.tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: false)
                    
                    if !(self.queryDetail?.finished)! {
                        if self.appDelegate.pubNub == nil {
                            let configuration = PNConfiguration(
                                publishKey: (self.queryDetail?.publishKey)!,
                                subscribeKey: (self.queryDetail?.subscribeKey)!
                            )
                            configuration.uuid = SesionManager.getToken()!
                            self.appDelegate.pubNub = PubNub.clientWithConfiguration(configuration)
                        }
                        self.appDelegate.pubNub?.addListener(self)
                        self.appDelegate.pubNub?.subscribeToChannels([(self.queryDetail?.channel)!], withPresence: true)
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    
    @IBAction func sendMessage(_ sender: UIButton) {
        
        var data = Dictionary<String, Any>()
        data["type"] = "MESSAGE"
        data["sapId"] = (SesionManager.getActiveUser()?.sapId)!
        data["description"] = self.input.text!
        
        self.appDelegate.pubNub?.publish(
            data,
            toChannel: (self.queryDetail?.channel)!,
            compressed: false,
            withCompletion: { (status) in }
        )
        
        self.input.text = ""
        self.input.resignFirstResponder()
        self.btnSend.isEnabled = false
    }
}


extension QueryChatController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.footer == nil) ? 1 : 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
            case 0:
                return self.messages.count
            default:
                return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
            case 0:
                let message = self.messages[indexPath.row]
                switch message.from {
                case "AFILIA":
                    let cellIdentifier = "messageAffiliateCell"
                    let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? QueryMessageCell
                    cell?.message.text = message.message
                    cell?.date.text = message.date
                    return cell!
                default:
                    let cellIdentifier = "messageAdminCell"
                    let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? QueryMessageCell
                    cell?.message.text = message.message
                    cell?.date.text = message.date
                    return cell!
                }
            default:
                let cellIdentifier = "messageFooterCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? QueryFooterCell
                cell?.message.text = self.footer
                return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return -1
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}


extension QueryChatController : UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        let  char = string.cString(using: String.Encoding.utf8)!
        let isBackSpace = strcmp(char, "\\b")
        var newCount = 0
        if isBackSpace == -92 {
            newCount = -1
        }
        else {
            newCount = string.count
        }
        self.btnSend.isEnabled = (self.input.text?.count)! + newCount > 0
        return true
    }
}


extension QueryChatController : PNObjectEventListener {

    func client(_ client: PubNub, didReceiveMessage message: PNMessageResult) {
        let channel = message.data.channel
        let publisher = message.data.publisher
        let data = message.data.message as! Dictionary<String, Any>
        if channel == self.queryDetail?.channel! {
            let type = data["type"] as! String
            if publisher == backend {
                switch type {
                    case "MESSAGE":
                        let toolbarDescription = data["toolbarDescription"] as! String
                        let footerDescription = data["footerDescription"] as! String
                        self.navigationItem.setTitle(
                            title: "#" + (self.queryDetail?.ticket)!,
                            subtitle: toolbarDescription
                        )
                        self.footer = footerDescription
                        let indexPath = IndexPath(row: 0, section: 1)
                        self.tableView.reloadData()
                        self.tableView.layoutIfNeeded()
                        self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
                        break
                    case "ASSIGN":
                        let toolbarDescription = data["toolbarDescription"] as! String
                        self.navigationItem.setTitle(
                            title: "#" + (self.queryDetail?.ticket)!,
                            subtitle: toolbarDescription
                        )
                        self.footer = nil
                        let indexPath = IndexPath(row: self.messages.count-1, section: 0)
                        self.tableView.reloadData()
                        self.tableView.layoutIfNeeded()
                        self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
                        break
                    case "FINISH":
                        let toolbarDescription = data["toolbarDescription"] as! String
                        let footerDescription = data["footerDescription"] as! String
                        self.navigationItem.setTitle(
                            title: "#" + (self.queryDetail?.ticket)!,
                            subtitle: toolbarDescription
                        )
                        self.footer = footerDescription
                        let indexPath = IndexPath(row: 0, section: 1)
                        self.tableView.reloadData()
                        self.tableView.layoutIfNeeded()
                        self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
                        self.input.isEnabled = false
                        self.btnSend.isEnabled = false
                        break
                    case "ERROR":
                        let toolbarDescription = data["toolbarDescription"] as! String
                        let footerDescription = data["footerDescription"] as! String
                        self.navigationItem.setTitle(
                            title: "#" + (self.queryDetail?.ticket)!,
                            subtitle: toolbarDescription
                        )
                        self.footer = footerDescription
                        let indexPath = IndexPath(row: 0, section: 1)
                        self.tableView.reloadData()
                        self.tableView.layoutIfNeeded()
                        self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
                        self.input.isEnabled = false
                        self.btnSend.isEnabled = false
                        break
                    default:
                        break
                }
            }
            else if type == "MESSAGE" {
                var sapId: Int!
                if let aux = data["sapId"] as? NSNumber {
                    sapId = aux as? Int
                }
                else {
                    sapId = Int(data["sapId"] as! String)
                }
                let description = data["description"] as! String
                if publisher == SesionManager.getToken()! || sapId == SesionManager.getActiveUser()?.sapId {
                    /* Afiliado */
                    let date = Date()
                    let calender = Calendar.current
                    let components = calender.dateComponents([.hour,.minute], from: date)
                    
                    let hour = components.hour
                    let minute = components.minute
                    
                    let message = QueryMessage()
                    message.from = "AFILIA"
                    message.message = description
                    message.date = String(format: "%02d", hour!) + ":" + String(format: "%02d", minute!)
                    self.messages.append(message)
                    
                    let indexPath = IndexPath(row: self.messages.count-1, section: 0)
                    self.tableView.insertRows(at: [indexPath], with: .bottom)
                    self.tableView.layoutIfNeeded()
                    self.tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: true)
                }
                else if sapId == -1 {
                    /* Admin */
                    let date = Date()
                    let calender = Calendar.current
                    let components = calender.dateComponents([.hour,.minute], from: date)
                    
                    let hour = components.hour
                    let minute = components.minute
                    
                    let message = QueryMessage()
                    message.from = "ADMIN"
                    message.message = description
                    message.date = String(format: "%02d", hour!) + ":" + String(format: "%02d", minute!)
                    self.messages.append(message)
                    
                    let indexPath = IndexPath(row: self.messages.count-1, section: 0)
                    self.tableView.insertRows(at: [indexPath], with: .bottom)
                    self.tableView.layoutIfNeeded()
                    self.tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: true)
                }
            }
        }
    }
    
    func client(_ client: PubNub, didReceivePresenceEvent event: PNPresenceEventResult) {
        // do-nothing
    }
    
    func client(_ client: PubNub, didReceive status: PNStatus) {
        if status.operation == .subscribeOperation {
            if status.category == .PNConnectedCategory || status.category == .PNReconnectedCategory {
                self.input.isEnabled = true
            }
            else if status.category == .PNUnexpectedDisconnectCategory {
                self.input.isEnabled = false
                self.input.resignFirstResponder()
            }
            else {
                self.input.isEnabled = false
                self.input.resignFirstResponder()
            }
        }
    }
}
