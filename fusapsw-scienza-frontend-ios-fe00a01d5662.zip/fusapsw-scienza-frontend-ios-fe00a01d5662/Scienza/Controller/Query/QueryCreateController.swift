//
//  QueryCreateController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/24/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class QueryCreateController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var queryList: [QueryType]! = []
    var queryId: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        let endpoint = Endpoint.queryType
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<QueryTypeResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.populateModel()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.queryList = data.body!
                    self.tableView.reloadData()
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    @IBAction func createQuery(_ sender: UIButton) {
        self.createQuery()
    }
    
    func createQuery() {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! QueryCreateCell
        if(!self.validate(cell)) {
            return
        }
        
        let data = QueryCreateRequest()
        let index = cell.queryType.tag
        let index2 = cell.categoryType.tag
        data.id = self.queryList[index].categories![index2].id
        data.desc = cell.message.text!
        
        SVProgressHUD.show()
        let endpoint = Endpoint.queryCreate
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<QueryCreateResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.createQuery()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.queryId = data.body!.id
                    self.performSegue(withIdentifier: "queryChatSegue", sender: nil)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.createQuery()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate(_ cell: QueryCreateCell) -> Bool {
        let queryTypeIndex = cell.queryType.tag
        let categoryTypeIndex = cell.categoryType.tag
        let message = cell.message.text!.trimmingCharacters(in: .whitespaces)
        if(queryTypeIndex < 0 || categoryTypeIndex < 0 || message.count == 0) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "queryChatSegue" {
            let destination = segue.destination as! QueryChatController
            destination.queryId = self.queryId!
        }
    }
}


extension QueryCreateController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "queryCreateCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? QueryCreateCell
        
        let queryTypePicker = UIPickerView()
        queryTypePicker.delegate = self
        queryTypePicker.tag = 0
        cell?.queryType.inputView = queryTypePicker
        cell?.queryType.tag = -1
        
        let categoryTypePicker = UIPickerView()
        categoryTypePicker.delegate = self
        categoryTypePicker.tag = 1
        cell?.categoryType.inputView = categoryTypePicker
        cell?.categoryType.tag = -1
        
        cell?.message.delegate = self
        cell?.messageCount.text = "\(500 - (cell?.message.text.count)!)"
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //return 520.0
        return -1
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}


extension QueryCreateController : UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! QueryCreateCell
        if pickerView.tag == 0 {
            return self.queryList.count
        }
        else if pickerView.tag == 1 && (cell.queryType.text?.count ?? 0) > 0 {
            let index = cell.queryType.tag
            return (self.queryList[index].categories?.count)!
        }
        else {
            return 0
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! QueryCreateCell
        if pickerView.tag == 0 {
            return self.queryList[row].name!
        }
        else {
            let index = cell.queryType.tag
            return self.queryList[index].categories![row].name
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! QueryCreateCell
        if pickerView.tag == 0 {
            cell.queryType.text = self.queryList[row].name
            cell.queryType.tag = row
            cell.categoryType.text = nil
            cell.categoryType.tag = -1
        }
        else {
            let index = cell.queryType.tag
            if index >= 0 {
                cell.categoryType.text = self.queryList[index].categories![row].name
                cell.categoryType.tag = row
            }
        }
    }
}


extension QueryCreateController : UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return textView.text.count + (text.count - range.length) <= 500;
    }
    
    func textViewDidChange(_ textView: UITextView) {
        UIView.setAnimationsEnabled(false)
        self.tableView.beginUpdates()
        textView.frame = CGRect(x: textView.frame.minX, y: textView.frame.minY, width: textView.frame.width, height: textView.contentSize.height)
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! QueryCreateCell
        cell.messageCount.text = "\(500 - textView.text.count)"
        self.tableView.endUpdates()
        UIView.setAnimationsEnabled(true)
    }
}
