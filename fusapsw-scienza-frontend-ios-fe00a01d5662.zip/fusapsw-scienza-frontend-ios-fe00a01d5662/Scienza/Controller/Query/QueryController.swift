//
//  QueryController.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/24/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class QueryController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var noResultsView: NoResultsView!
    
    var queryList: [Query]! = []
    var appDelegate: AppDelegate!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        self.tableView.isHidden = true
        self.noResultsView.isHidden = true
        self.noResultsView.message.text = "No ha creado ninguna solicitud."
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.appDelegate.pubNub?.unsubscribeFromAll()
        self.populateModel()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        let endpoint = Endpoint.queryList
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<QueryResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.populateModel()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else if data.body!.count == 0 {
                    self.noResultsView.isHidden = false
                    self.tableView.isHidden = true
                }
                else {
                    self.queryList = []
                    self.queryList.insert(contentsOf: data.body!, at: self.queryList.count)
                    self.tableView.reloadData()
                    self.noResultsView.isHidden = true
                    self.tableView.isHidden = false
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func deleteQuery(_ indexPath: IndexPath) {
        let query = self.queryList[indexPath.row]
        let data = QueryDeleteRequest()
        data.idQuery = query.id
        SVProgressHUD.show()
        let endpoint = Endpoint.queryDelete
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<Response>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.deleteQuery(indexPath)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.queryList.remove(at: indexPath.row)
                    self.tableView.beginUpdates()
                    self.tableView.deleteRows(at: [indexPath], with: .automatic)
                    self.tableView.endUpdates()
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.deleteQuery(indexPath)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "queryChatSegue" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let query = self.queryList[indexPath.row]
                let destination = segue.destination as! QueryChatController
                destination.queryId = query.id!
            }
        }
    }
    
    @IBAction func createQuery(_ sender: UIButton) {
        self.performSegue(withIdentifier: "queryCreateSegue", sender: nil)
    }
}


extension QueryController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.queryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "queryCell"
        let query = self.queryList[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? QueryCell
        cell?.ticket.text = "#\(query.ticket!)"
        cell?.query.text = query.queryType
        cell?.category.text = query.categoryType
        cell?.dateTime.text = query.lastMessageDate
        cell?.message.text = query.lastMessage
        cell?.unreadMessages.text = String(query.unreadMessages!)
        cell?.unreadMessages.layer.cornerRadius = 12.0
        cell?.unreadMessages.layer.masksToBounds = true
        cell?.unreadMessages.isHidden = query.unreadMessages! == 0
        cell?.backgroundColor = (indexPath.row % 2 == 0) ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : #colorLiteral(red: 0.9137254902, green: 0.9137254902, blue: 0.9137254902, alpha: 1)
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "queryChatSegue", sender: self)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return self.queryList[indexPath.row].closed ?? false
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let alert = UIAlertController(title: "", message: Messages.eliminarConsulta, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertAction.Style.default, handler: nil))
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                self.deleteQuery(indexPath)
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}

