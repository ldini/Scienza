//
//  NotificacionesDetalles.swift
//  Scienza
//
//  Created by Kender on 20/2/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import WebKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class NotificationDetailController: UIViewController, WKNavigationDelegate {

    @IBOutlet weak var txtTitulo: UILabel!
    @IBOutlet var containerView: UIView!
    
    var webView: WKWebView!
    var notificationId: Int!
    var notificationDetail: NotificationDetail!
    var orderId: Int!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateModel()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func populateModel() {
        SVProgressHUD.show()
        let endpoint = String(format: Endpoint.notificationDetail, self.notificationId)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<NotificationDetailResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.notificationDetail = data.body!
                    self.txtTitulo.text = self.notificationDetail.title?.uppercased()
                    let frame = self.containerView.frame
                    self.webView = WKWebView(
                        frame: CGRect(x:0, y:0, width: frame.width, height: frame.height)
                    )
                    self.containerView.addSubview(self.webView)
                    
                    let htmlInit = """
                        <html>
                            <head>
                                <meta name='viewport' content='initial-scale=1.0'/>
                                <style>
                                @font-face
                                {
                                    font-family: 'Roboto';
                                    font-weight: normal;
                                    src: url(Roboto-Regular.ttf);
                                }
                                @font-face
                                {
                                    font-family: 'Roboto';
                                    font-weight: bold;
                                    src: url(Roboto-Bold.ttf);
                                }
                                @font-face
                                {
                                    font-family: 'Roboto';
                                    font-weight: 900;
                                    src: url(Roboto-Black.ttf);
                                }
                                @font-face
                                {
                                    font-family: 'Roboto';
                                    font-weight: 200;
                                    src: url(Roboto-Light.ttf);
                                }
                                @font-face
                                {
                                    font-family: 'Roboto';
                                    font-weight: 500;
                                    src: url(Roboto-Medium.ttf);
                                }
                                </style>
                            </head>
                        <body style="font-family: 'Roboto';">
                    """
                    let htmlEnd = "</body></html>"
                    let message = htmlInit + self.notificationDetail.message! + htmlEnd
                    self.webView.scrollView.bounces = false
                    self.webView.scrollView.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: -15)
                    self.webView.navigationDelegate = self
                    self.webView.loadHTMLString(message, baseURL: Bundle.main.bundleURL)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == WKNavigationType.linkActivated {
            if (navigationAction.request.url?.absoluteString.contains("pedido:"))! {
                let orderArr = navigationAction.request.url?.absoluteString.components(separatedBy: ":")
                self.orderId = Int(orderArr![1])
                self.performSegue(withIdentifier: "orderDetailSegue", sender: nil)
                decisionHandler(WKNavigationActionPolicy.cancel)
                return
            }
        }
        decisionHandler(WKNavigationActionPolicy.allow)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "orderDetailSegue" {
            let destination = segue.destination as! OrderDetailController
            destination.orderId = self.orderId
        }
    }
}
