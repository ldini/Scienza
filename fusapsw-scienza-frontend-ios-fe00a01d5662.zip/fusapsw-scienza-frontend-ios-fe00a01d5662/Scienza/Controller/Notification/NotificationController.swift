//
//  Notificaciones.swift
//  Scienza
//
//  Created by Kender on 17/2/17.
//  Copyright © 2017 fusap. All rights reserved.
//
import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class NotificationController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var noResultsView: NoResultsView!
    
    var notificationList: [Notification]! = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.estimatedRowHeight = 160.0
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.populateModel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        self.tableView.isHidden = true
        self.noResultsView.isHidden = true
        let request = HttpRequest.instance.createGetRequest(endpoint: Endpoint.notificationList)
        AF.request(request).responseObject { (response: DataResponse<NotificationResponse>) in
            switch response.result {
                case let .success(data):
                    if data.header?.code != 0 {
                        let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        break
                    }
                    else if data.body!.count == 0 {
                        self.noResultsView.isHidden = false
                    }
                    else {
                        self.notificationList = data.body!
                        self.tableView.reloadData()
                        self.tableView.isHidden = false
                    }
                    break
                case .failure:
                    let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func deleteNotification(_ indexPath: IndexPath) {
        let notification = self.notificationList[indexPath.row]
        let data = NotificationDeleteRequest()
        data.idNotification = notification.id
        SVProgressHUD.show()
        let endpoint = Endpoint.notificationDelete
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<Response>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.deleteNotification(indexPath)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.notificationList.remove(at: indexPath.row)
                    self.tableView.beginUpdates()
                    self.tableView.deleteRows(at: [indexPath], with: .automatic)
                    self.tableView.endUpdates()
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.deleteNotification(indexPath)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "notificationDetailSegue" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let notification = self.notificationList[indexPath.row]
                let destination = segue.destination as! NotificationDetailController
                destination.notificationId = notification.id!
            }
        }
    }
}


extension NotificationController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.notificationList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "celdaNotificaciones"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? NotificationCell
        let notification = self.notificationList[indexPath.row]
        cell?.lblFecha.text = notification.date!
        cell?.lblTitulo.text = notification.title!
        cell?.lblMensaje.text = notification.message!
        cell?.lblNotificacionNuevo.layer.cornerRadius = 10
        cell?.lblNotificacionNuevo.text = "NUEVO"
        cell?.lblNotificacionNuevo.isHidden = !(notification.new!)
        cell?.backgroundColor = (indexPath.row % 2 == 0) ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : #colorLiteral(red: 0.9137254902, green: 0.9137254902, blue: 0.9137254902, alpha: 1)
        return cell!
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let alert = UIAlertController(title: "", message: Messages.eliminarNotificacion, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertAction.Style.default, handler: nil))
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                self.deleteNotification(indexPath)
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 135.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}

