//
//  OtraPantalla.swift
//  Scienza
//
//  Created by Kender on 12/1/17.
//  Copyright © 2017 fusap. All rights reserved.
//
import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class BindAffiliateController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBindAffiliate(_ sender: UIButton!) {
        self.bindAffiliate()
    }
    
    func bindAffiliate() {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! BindAffiliateCell
        if(!self.validate(cell)) {
            return
        }
        
        /* Fuerzo a que se envie por el usuario principal */
        let token = SesionManager.getToken()!
        let user = SesionManager.getConfiguration()?.user!
        let data = BindAffiliateRequest()
        data.documentNumber = Int(cell.documentNumber.text!.trimmingCharacters(in: .whitespaces))
        data.sapId = Int(cell.sapId.text!.trimmingCharacters(in: .whitespaces))
        
        SVProgressHUD.show()
        let endpoint = Endpoint.bindAffiliate
        let request = HttpRequest.instance.createPostRequest(
            endpoint: endpoint,
            data: data,
            token: token,
            user: user,
            timeout: nil
        )
        AF.request(request).responseObject { (response: DataResponse<BindAffiliateResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.bindAffiliate()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    let newUser = data.body!
                    SesionManager.addUser(user: newUser)
                    SesionManager.changeUser(user: newUser)
                    self.performSegue(withIdentifier: "unwindHome", sender: nil)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.bindAffiliate()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate(_ cell: BindAffiliateCell) -> Bool {
        let documentNumber = cell.documentNumber.text!.trimmingCharacters(in: .whitespaces)
        let sapId = cell.sapId.text!.trimmingCharacters(in: .whitespaces)
        if(documentNumber.count == 0 || sapId.count == 0) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(documentNumber.count > 8) {
            let alert = UIAlertController(title: "", message: Messages.longitudDni, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(sapId.count > 8) {
            let alert = UIAlertController(title: "", message: Messages.longitudSapID, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }
        return false
    }
}


extension BindAffiliateController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "bindAffiliateCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? BindAffiliateCell
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
