//
//  altaAfiliado.swift
//  Scienza
//
//  Created by fusap on 29/12/16.
//  Copyright (c) 2016 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class RegistrationController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var configuration: Configuration!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "registrationErrorSegue" {
            let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! RegistrationCell
            let destination = segue.destination as! RegistrationErrorController
            destination.registrationCell = cell
        }
        if segue.identifier == "registrationSuccessSegue" {
            let destination = segue.destination as! RegistrationSuccessController
            destination.configuration = self.configuration
        }
        if segue.identifier == "termsAndConditionSegue" {
            let destination = segue.destination as! TermsAndConditionController
            destination.grayColor = true
        }
    }
    
    @IBAction func btnCambioCheck(_ sender: UIButton!) {
        if(sender.tag == 0) {
            sender.setImage(UIImage(named: "general_check_on"), for: .normal)
            sender.tag = 1
        } else {
            sender.setImage(UIImage(named: "general_check_off"), for: .normal)
            sender.tag = 0
        }
    }
    
    @IBAction func btnRegistrate(_ sender: UIButton!) {
        self.registrate()
    }
    
    func registrate() {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! RegistrationCell
        if(!self.validate(cell)) {
            return
        }
        
        let data = RegistrationRequest()
        data.documentNumber = Int(cell.documentNumber.text!.trimmingCharacters(in: .whitespaces))
        data.sapId = Int(cell.sapId.text!.trimmingCharacters(in: .whitespaces))
        data.password = cell.password.text!.trimmingCharacters(in: .whitespaces)
        
        SVProgressHUD.show()
        let endpoint = Endpoint.registration
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<RegistrationResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    switch data.header?.code {
                    case 1:
                        let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        break
                    default:
                        self.performSegue(withIdentifier: "registrationErrorSegue", sender: self)
                        break
                    }
                }
                else {
                    self.configuration = data.body!
                    self.performSegue(withIdentifier: "registrationSuccessSegue", sender: self)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.registrate()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate(_ cell: RegistrationCell) -> Bool {
        let documentNumber = cell.documentNumber.text!.trimmingCharacters(in: .whitespaces)
        let sapId = cell.sapId.text!.trimmingCharacters(in: .whitespaces)
        let password = cell.password.text!.trimmingCharacters(in: .whitespaces)
        let password2 = cell.password2.text!.trimmingCharacters(in: .whitespaces)
        if(documentNumber.count == 0 || sapId.count == 0 || password.count == 0 || password2.count == 0) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(documentNumber.count > 8) {
            let alert = UIAlertController(title: "", message: Messages.longitudDni, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(sapId.count > 8) {
            let alert = UIAlertController(title: "", message: Messages.longitudSapID, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(password.count < 6) {
            let alert = UIAlertController(title: "", message: Messages.longitudClave, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(password != password2) {
            let alert = UIAlertController(title: "", message: Messages.clavesDistintas, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(cell.btnCheckTyC.tag == 0) {
            let alert = UIAlertController(title: "", message: Messages.aceptarTerminosCond, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }        
        return false
    }
}


extension RegistrationController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "registrationCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? RegistrationCell
        cell?.btnCheckTyC.setImage(UIImage(named: "general_check_off"), for: .normal)
        cell?.btnCheckTyC.tag = 0
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
