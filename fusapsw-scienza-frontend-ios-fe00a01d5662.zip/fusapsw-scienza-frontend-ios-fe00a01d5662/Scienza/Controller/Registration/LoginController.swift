//
//  inicioSesion.swift
//  Scienza
//
//  Created by fusap on 22/12/16.
//  Copyright © 2016 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class InicioSesion: UIViewController {
    
    @IBOutlet weak var imageBackground: UIImageView!
    @IBOutlet weak var txtUsuario: UITextField!
    @IBOutlet weak var txtClave: UITextField!
    
    var configuration: Configuration!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        self.txtUsuario.attributedPlaceholder = NSAttributedString(string:"DNI", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        self.txtClave.attributedPlaceholder = NSAttributedString(string:"CONTRASEÑA", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        
        let coverBackground = CALayer()
        coverBackground.frame = CGRect(
            x: 0,
            y: 0,
            width: UIScreen.main.bounds.width,
            height: UIScreen.main.bounds.height
        )
        coverBackground.backgroundColor = UIColor.black.cgColor
        coverBackground.opacity = 0.1
        self.imageBackground.layer.addSublayer(coverBackground)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        super.viewWillAppear(animated)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "registrationSuccessSegue" {
            let destination = segue.destination as! RegistrationSuccessController
            destination.configuration = self.configuration
        }
    }
    
    @IBAction func unwindLogin(segue: UIStoryboardSegue!) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func login(_: AnyObject) {
        if(!self.validate()) {
            return
        }
        
        let data = LoginRequest()
        data.userName = String(describing: self.txtUsuario.text!)
        data.password = self.txtClave.text!
        
        SVProgressHUD.show()
        let endpoint = Endpoint.login
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<LoginResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error!, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.configuration = data.body!
                    if (self.configuration.user?.verifyProfile)! {
                        self.performSegue(withIdentifier: "registrationSuccessSegue", sender: self)
                    }
                    else {
                        SesionManager.createSession(configuration: self.configuration)
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let homeController = storyboard.instantiateViewController(withIdentifier: "HomeNavigation") as? UINavigationController
                        UIApplication.setRootView(homeController!, options: UIApplication.loginAnimation)
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate() -> Bool {
        let usuario = self.txtUsuario.text
        let clave = self.txtClave.text
        if(usuario == "" || clave == ""){
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }
        return false
    }
}
