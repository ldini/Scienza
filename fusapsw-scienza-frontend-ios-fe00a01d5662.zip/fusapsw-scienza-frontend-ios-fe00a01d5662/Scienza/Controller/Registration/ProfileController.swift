//
//  EditPerfil.swift
//  Scienza
//
//  Created by Kender on 25/1/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class ProfileController: UIViewController {

    @IBOutlet var avatarView: UIView!
    @IBOutlet var verifyView: UIView!
    @IBOutlet var topHeaderView: UIView!
    @IBOutlet var locationView: UIView!
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var documentNumber: UITextField!
    @IBOutlet var gender: UITextField!
    @IBOutlet weak var acronym: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet var birthdate: UITextField!
    @IBOutlet weak var healthInsurance: UITextField!
    
    @IBOutlet weak var street: UITextField!
    @IBOutlet weak var streetNumber: UITextField!
    @IBOutlet weak var floor: UITextField!
    @IBOutlet weak var department: UITextField!
    @IBOutlet weak var postalCode: UITextField!
    @IBOutlet weak var province: UITextField!
    @IBOutlet weak var locality: UITextField!
    var latitude: String?
    var longitude: String?
    
    @IBOutlet weak var personalPhoneCode: UITextField!
    @IBOutlet weak var personalPhone: UITextField!
    @IBOutlet weak var cellPhoneCode: UITextField!
    @IBOutlet weak var cellPhone: UITextField!
    @IBOutlet weak var workPhoneCode: UITextField!
    @IBOutlet weak var workPhone: UITextField!
    @IBOutlet var cellCompanyCode: UITextField!
    @IBOutlet var personalDataView: UIView!
    @IBOutlet var addressView: UIView!
    @IBOutlet var phoneView: UIView!
    @IBOutlet var btnEditProfile: UIButton!
    
    
    var loggedIn: Bool!
    var user: User!
    var configuration: Configuration!
    var companyList: [CellCompany] = []
    var genderList: [(code:String?, value:String)] = []
    var birthdateDayList: [(code:Int?, value:String)] = []
    var birthdateMonthList: [(code:Int?, value:String)] = []
    var birthdateYearList: [(code:Int?, value:String)] = []
    var birthdateTag: (day:Int, month:Int, year:Int) = (day:0, month:0, year:0)
    var profileAvatarController: ProfileAvatarController!
    var profileVerifyController: ProfileVerifyController!
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateModel()
        self.navigationController?.isNavigationBarHidden = !self.loggedIn
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = !self.loggedIn
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "profileAvatarSegue" {
            let destination = segue.destination as! ProfileAvatarController
            self.profileAvatarController = destination
        }
        if segue.identifier == "profileVerifySegue" {
            let destination = segue.destination as! ProfileVerifyController
            self.profileVerifyController = destination
        }
        if segue.identifier == "profileAddressSegue" {
            let destination = segue.destination as! ProfileAddressController
            destination.user = self.user
        }
    }
    
    func populateModel() {
        self.avatarView.isHidden = true
        self.verifyView.isHidden = true
        self.topHeaderView.isHidden = true
        if loggedIn {
            self.avatarView.isHidden = false
            self.topHeaderView.isHidden = false
            self.profileAvatarController.avatar.image = user.avatarAsImage()
            self.profileAvatarController.fullName.text = "\(user.firstName) \(user.lastName)"
            self.profileAvatarController.fullDocumentNumber.text = "DNI \(user.documentNumber)"
        }
        else {
            self.verifyView.isHidden = false
        }
        
        SVProgressHUD.show()
        let endpoint = Endpoint.profile
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint, token: configuration.token, user: user)
        let endpointCC = Endpoint.cellCompany
        let requestCC = HttpRequest.instance.createGetRequest(endpoint: endpointCC, token: configuration.token, user: user)
        AF.request(request).responseObject { (response: DataResponse<ProfileResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: {
                        action in self.populateModel()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    SVProgressHUD.dismiss()
                }
                else
                {
                    AF.request(requestCC).responseObject { (response: DataResponse<CellCompanyResponse>) in
                        switch response.result {
                        case let .success(dataCC):
                            if dataCC.header?.code != 0 {
                                let alert = UIAlertController(title: "", message: dataCC.header?.error, preferredStyle: .alert)
                                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: {
                                    action in self.populateModel()
                                }))
                                self.present(alert, animated: true, completion: nil)
                            }
                            else {
                                let profile = data.body!
                                
                                self.genderList.append((code: nil, value: ""))
                                self.genderList.append((code: "M", value: "Masculino"))
                                self.genderList.append((code: "F", value: "Femenino"))
                                
                                self.birthdateDayList.append((code: nil, value: ""))
                                for day in 1...31 {
                                     self.birthdateDayList.append((code: day, value: String(format: "%02d", day)))
                                }
                                
                                self.birthdateMonthList.append((code: nil, value: ""))
                                self.birthdateMonthList.append((code: 1, value: "Enero"))
                                self.birthdateMonthList.append((code: 2, value: "Febrero"))
                                self.birthdateMonthList.append((code: 3, value: "Marzo"))
                                self.birthdateMonthList.append((code: 4, value: "Abril"))
                                self.birthdateMonthList.append((code: 5, value: "Mayo"))
                                self.birthdateMonthList.append((code: 6, value: "Junio"))
                                self.birthdateMonthList.append((code: 7, value: "Julio"))
                                self.birthdateMonthList.append((code: 8, value: "Agosto"))
                                self.birthdateMonthList.append((code: 9, value: "Septiembre"))
                                self.birthdateMonthList.append((code: 10, value: "Octubre"))
                                self.birthdateMonthList.append((code: 11, value: "Noviembre"))
                                self.birthdateMonthList.append((code: 12, value: "Diciembre"))
                                
                                let date = Date()
                                let calendar = Calendar.current
                                let fromYear = calendar.component(.year, from: date)
                                let toYear = fromYear - 100
                                self.birthdateYearList.append((code: nil, value: ""))
                                for year in stride(from: fromYear, to: toYear, by: -1) {
                                    self.birthdateYearList.append((code: year, value: "\(year)"))
                                }
                                
                                let cellCompany = CellCompany()
                                cellCompany.code = nil
                                cellCompany.desc = ""
                                self.companyList.append(cellCompany)
                                self.companyList.append(contentsOf: dataCC.body!)
                                
                                self.firstName.text = profile.firstName
                                self.lastName.text = profile.lastName
                                self.documentNumber.text = String(profile.documentNumber ?? 0)
                                self.gender.tag = self.genderList.firstIndex(
                                    where: { $0.code == profile.gender }
                                ) ?? 0
                                self.gender.text = self.genderList[self.gender.tag].value
                                self.acronym.text = profile.acronym
                                self.email.text = profile.email
                                self.birthdate.text = profile.birthdate
                                self.healthInsurance.text = profile.healthInsurance
                                
                                self.street.text = profile.street
                                self.streetNumber.text = String(profile.streetNumber ?? 0)
                                self.floor.text = profile.floor
                                self.department.text = profile.department
                                self.postalCode.text = profile.postalCode
                                self.province.text = profile.province
                                self.locality.text = profile.locality
                                self.latitude = profile.latitude
                                self.longitude = profile.longitude
                                
                                self.street.addTarget(
                                    self, action: #selector(self.addressChanged), for: .editingChanged
                                )
                                self.streetNumber.addTarget(
                                    self, action: #selector(self.addressChanged), for: .editingChanged
                                )
                                self.postalCode.addTarget(
                                    self, action: #selector(self.addressChanged), for: .editingChanged
                                )
                                self.province.addTarget(
                                    self, action: #selector(self.addressChanged), for: .editingChanged
                                )
                                self.locality.addTarget(
                                    self, action: #selector(self.addressChanged), for: .editingChanged
                                )
                                
                                self.personalPhoneCode.text = profile.personalPhoneCode
                                self.personalPhone.text = profile.personalPhone
                                self.cellPhoneCode.text = profile.cellPhoneCode
                                self.cellPhone.text = profile.cellPhone
                                self.cellCompanyCode.tag = self.companyList.firstIndex(
                                    where: { $0.code == profile.cellCompanyCode }
                                ) ?? 0
                                self.cellCompanyCode.text = self.companyList[self.cellCompanyCode.tag].desc
                                self.workPhoneCode.text = profile.workPhoneCode
                                self.workPhone.text = profile.workPhone
                                
                                if let birthdateAux = profile.birthdate {
                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "dd/MM/yyyy"
                                    dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
                                    if let date = dateFormatter.date(from: birthdateAux) {
                                        let calendar = Calendar.current
                                        let day = calendar.component(.day, from: date) + 1
                                        let month = calendar.component(.month, from: date)
                                        let year = calendar.component(.year, from: date)
                                        self.birthdateTag = (
                                            day: self.birthdateDayList.firstIndex(where: { $0.code == day }) ?? 0,
                                            month: self.birthdateMonthList.firstIndex(where: { $0.code == month }) ?? 0,
                                            year: self.birthdateYearList.firstIndex(where: { $0.code == year }) ?? 0
                                        )
                                    }
                                }
                                
                                let genderPicker = UIPickerView()
                                genderPicker.delegate = self
                                genderPicker.tag = 0
                                genderPicker.selectRow(self.gender.tag, inComponent: 0, animated: true)
                                self.gender.inputView = genderPicker
                                
                                let birthdatePicker = UIPickerView()
                                birthdatePicker.delegate = self
                                birthdatePicker.tag = 1
                                birthdatePicker.selectRow(self.birthdateTag.day, inComponent: 0, animated: true)
                                birthdatePicker.selectRow(self.birthdateTag.month, inComponent: 1, animated: true)
                                birthdatePicker.selectRow(self.birthdateTag.year, inComponent: 2, animated: true)
                                self.birthdate.inputView = birthdatePicker
                                
                                let cellCompanyPicker = UIPickerView()
                                cellCompanyPicker.delegate = self
                                cellCompanyPicker.tag = 2
                                cellCompanyPicker.selectRow(self.cellCompanyCode.tag, inComponent: 0, animated: true)
                                self.cellCompanyCode.inputView = cellCompanyPicker
                                
                                if profile.pendingVerifyAdmin! {
                                    self.disableFields()
                                    self.btnEditProfile.isHidden = true
                                    let alert = UIAlertController(title: "", message: Messages.verificacionPendiente, preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                else {
                                    self.enableFields()
                                }
                            }
                            break
                        case .failure:
                            let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                            alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                                self.populateModel()
                            }))
                            self.present(alert, animated: true, completion: nil)
                            break
                        }
                        SVProgressHUD.dismiss()
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                SVProgressHUD.dismiss()
                break
            }
        }
    }
            
    func disableFields(){
        self.firstName.isUserInteractionEnabled = false
        self.lastName.isUserInteractionEnabled = false
        self.documentNumber.isUserInteractionEnabled = false
        self.gender.isUserInteractionEnabled = false
        self.acronym.isUserInteractionEnabled = false
        self.email.isUserInteractionEnabled = false
        self.birthdate.isUserInteractionEnabled = false
        self.healthInsurance.isUserInteractionEnabled = false
        
        self.locationView.isHidden = true
        self.street.isUserInteractionEnabled = false
        self.streetNumber.isUserInteractionEnabled = false
        self.floor.isUserInteractionEnabled = false
        self.department.isUserInteractionEnabled = false
        self.postalCode.isUserInteractionEnabled = false
        self.province.isUserInteractionEnabled = false
        self.locality.isUserInteractionEnabled = false
        
        self.personalPhoneCode.isUserInteractionEnabled = false
        self.personalPhone.isUserInteractionEnabled = false
        self.cellPhoneCode.isUserInteractionEnabled = false
        self.cellPhone.isUserInteractionEnabled = false
        self.cellCompanyCode.isUserInteractionEnabled = false
        self.workPhoneCode.isUserInteractionEnabled = false
        self.workPhone.isUserInteractionEnabled = false
    }
    
    func enableFields(){
        self.firstName.isUserInteractionEnabled = true
        self.lastName.isUserInteractionEnabled = true
        self.documentNumber.isUserInteractionEnabled = false  //No editable
        self.gender.isUserInteractionEnabled = true
        self.acronym.isUserInteractionEnabled = false //No editable
        self.email.isUserInteractionEnabled = true
        self.birthdate.isUserInteractionEnabled = true
        self.healthInsurance.isUserInteractionEnabled = false //No editable
        
        self.locationView.isHidden = false
        self.street.isUserInteractionEnabled = true
        self.streetNumber.isUserInteractionEnabled = true
        self.floor.isUserInteractionEnabled = true
        self.department.isUserInteractionEnabled = true
        self.postalCode.isUserInteractionEnabled = true
        self.province.isUserInteractionEnabled = true
        self.locality.isUserInteractionEnabled = true
        
        self.personalPhoneCode.isUserInteractionEnabled = true
        self.personalPhone.isUserInteractionEnabled = true
        self.cellPhoneCode.isUserInteractionEnabled = true
        self.cellPhone.isUserInteractionEnabled = true
        self.cellCompanyCode.isUserInteractionEnabled = true
        self.workPhoneCode.isUserInteractionEnabled = true
        self.workPhone.isUserInteractionEnabled = true
    }
    
    @IBAction func editProfile(_ sender: UIButton) {
        self.editProfile()
    }
    
    func editProfile() {
        if(!self.validate()) {
            return
        }
        
        let data = ProfileEditRequest()
        data.firstName = self.firstName.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.lastName = self.lastName.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.acronym = self.acronym.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.gender = self.genderList[self.gender.tag].code
        data.birthdate = self.birthdate.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.province = self.province.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.locality = self.locality.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.street = self.street.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.streetNumber = Int(self.streetNumber.text!) ?? 0
        data.floor = self.floor.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.department = self.department.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.postalCode = self.postalCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.latitude = self.latitude
        data.longitude = self.longitude
        data.personalPhoneCode = self.personalPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.personalPhone = self.personalPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.workPhoneCode = self.workPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.workPhone = self.workPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.cellPhoneCode = self.cellPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.cellPhone = self.cellPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        data.cellCompanyCode = self.companyList[self.cellCompanyCode.tag].code
        data.email = self.email.text?.trimmingCharacters(in: .whitespaces) ?? ""
        
        SVProgressHUD.show()
        let endpoint = Endpoint.profileEdit
        let request = HttpRequest.instance.createPostRequest(
            endpoint: endpoint,
            data: data,
            token: configuration.token,
            user: user,
            timeout: nil
        )
        AF.request(request).responseObject { (response: DataResponse<ProfileEditResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error!, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: {
                        action in self.editProfile()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    if self.loggedIn {
                        if let message = data.body?.message {
                            let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                                self.performSegue(withIdentifier: "unwindHome", sender: self)
                            }))
                            self.present(alert, animated: true, completion: nil)
                        }
                        else {
                            self.performSegue(withIdentifier: "unwindHome", sender: self)
                        }
                    }
                    else {
                        self.user.verifyProfile = false
                        SesionManager.createSession(configuration: self.configuration)
                        if let message = data.body?.message {
                            let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                let homeController = storyboard.instantiateViewController(withIdentifier: "HomeNavigation") as? UINavigationController
                                UIApplication.setRootView(homeController!, options: UIApplication.loginAnimation)
                            }))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: {
                    action in self.editProfile()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate() -> Bool {
        let firstName = self.firstName.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let lastName = self.lastName.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let birthdate = self.birthdate.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let province = self.province.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let locality = self.locality.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let street = self.street.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let streetNumber = self.streetNumber.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let postalCode = self.postalCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let email = self.email.text?.trimmingCharacters(in: .whitespaces) ?? ""
        
        let personalPhoneCode = self.personalPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let personalPhone = self.personalPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let workPhoneCode = self.workPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let workPhone = self.workPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let cellPhoneCode = self.cellPhoneCode.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let cellPhone = self.cellPhone.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let cellCompanyCode = self.companyList[self.cellCompanyCode.tag].desc ?? ""
        
        var valid = true
        
        if(firstName.count == 0 || lastName.count == 0 || self.gender.tag == 0 || birthdate.count == 0 ||
           province.count == 0 || locality.count == 0 || street.count == 0 || streetNumber.count == 0 ||
           postalCode.count == 0 || email.count == 0
        ) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            valid = false
        }
        if((personalPhoneCode.count + personalPhone.count) > 0) {
            if(personalPhoneCode.count == 0 || personalPhone.count == 0) {
                let alert = UIAlertController(title: "", message: Messages.completePhoneOblig, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                valid = false
            }
        }
        if((workPhoneCode.count + workPhone.count) > 0) {
            if(workPhoneCode.count == 0 || workPhone.count == 0) {
                let alert = UIAlertController(title: "", message: Messages.completePhoneOblig, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                valid = false
            }
        }
        if((cellPhoneCode.count + cellPhone.count + cellCompanyCode.count) > 0) {
            if(cellPhoneCode.count == 0 || cellPhone.count == 0 || cellCompanyCode.count == 0) {
                let alert = UIAlertController(title: "", message: Messages.completeCellPhoneOblig, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                valid = false
            }
        }
        return valid
    }
    
    @IBAction func unwindProfile(segue: UIStoryboardSegue!) {
        let source = segue.source as! ProfileAddressDetailController
        self.province.text = source.province
        self.locality.text = source.locality
        self.street.text = source.street
        self.streetNumber.text = source.streetNumber
        self.floor.text = source.floor
        self.department.text = source.department
        self.postalCode.text = source.postalCode
        self.latitude = source.latitude
        self.longitude = source.longitude
    }
    
    
    @objc func addressChanged(textField: UITextField) {
        self.latitude = nil
        self.longitude = nil
    }
}


extension ProfileController : UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        switch pickerView.tag {
            case 0:
                return 1
            case 1:
                return 3
            case 2:
                return 1
            default:
                return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
            case 0:
                return self.genderList.count
            case 1:
                switch component {
                    case 0:
                        return self.birthdateDayList.count
                    case 1:
                        return self.birthdateMonthList.count
                    case 2:
                        return self.birthdateYearList.count
                    default:
                        return 0
                }
            case 2:
                return self.companyList.count
            default:
                return 0
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
            case 0:
                return self.genderList[row].value
            case 1:
                switch component {
                    case 0:
                        return self.birthdateDayList[row].value
                    case 1:
                        return self.birthdateMonthList[row].value
                    case 2:
                        return self.birthdateYearList[row].value
                    default:
                        return ""
                }
            case 2:
                return self.companyList[row].desc
            default:
                return ""
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
            case 0:
                self.gender.text = self.genderList[row].value
                self.gender.tag = row
                break
            case 1:
                switch component {
                    case 0:
                        self.birthdateTag.day = row
                        break
                    case 1:
                        self.birthdateTag.month = row
                        break
                    case 2:
                        self.birthdateTag.year = row
                        break
                    default:
                        break
                }
                let dayIndex = self.birthdateTag.day
                let monthIndex = self.birthdateTag.month
                let yearIndex = self.birthdateTag.year
                if dayIndex > 0 && monthIndex > 0 && yearIndex > 0 {
                    let day = self.birthdateDayList[dayIndex].value
                    let month = String(format: "%02d", self.birthdateMonthList[monthIndex].code!)
                    let year = self.birthdateYearList[yearIndex].value
                    self.birthdate.text = "\(day)/\(month)/\(year)"
                }
                else {
                    self.birthdate.text = ""
                }
                break
            case 2:
                self.cellCompanyCode.text = self.companyList[row].desc
                self.cellCompanyCode.tag = row
                break
            default:
                return
        }
    }
}

