//
//  ProfileAddressController.swift
//  Scienza
//
//  Created by Gaston Mancini on 12/29/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import GoogleMaps
import GooglePlaces


class ProfileAddressController: UIViewController {
    
    @IBOutlet var subtitle: UILabel!
    @IBOutlet var mapView: GMSMapView!
    @IBOutlet var addressView: UIView!
    @IBOutlet var addressViewConstraint: NSLayoutConstraint!
    @IBOutlet var addressHeightConstraint: NSLayoutConstraint!
    
    var user: User!
    var addressDetailController: ProfileAddressDetailController?
    var gmsMarker: GMSMarker?
    
    let locationManager = CLLocationManager()
    let gmsStyle = """
        [
            {
                "featureType": "administrative",
                "elementType": "geometry",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "poi",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "road",
                "elementType": "labels.icon",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "transit",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            }
        ]
    """
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.subtitle.text = "\(self.user.firstName), busque su dirección en el mapa."
        
        let searchIcon = UIButton(type: .system)
        searchIcon.setImage(UIImage(named: "general_search")?.withRenderingMode(.alwaysOriginal), for: .normal)
        searchIcon.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        searchIcon.addTarget(self, action: #selector(searchPlace), for: .touchUpInside)
        self.navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: searchIcon)]
        self.navigationController?.isNavigationBarHidden = false
        
        self.setupGoogleMaps()
        self.centerViewOnArgentina()
        self.checkLocationServices()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.2862745098, green: 0.3647058824, blue: 0.4117647059, alpha: 1)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.6352941176, green: 0, blue: 0.1137254902, alpha: 1)
    }
    
    @objc func searchPlace() {
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.tintColor = UIColor.red
        autocompleteController.delegate = self
        
        let filter = GMSAutocompleteFilter()
        filter.country = "AR"
        autocompleteController.autocompleteFilter = filter
        
        self.present(autocompleteController, animated: true, completion: nil)
    }
    
    func setupGoogleMaps() {
        self.mapView.delegate = self
        do {
            self.mapView.mapStyle = try GMSMapStyle(jsonString: gmsStyle)
        }
        catch {
            NSLog("One or more of the map styles failed to load. \(error)")
        }
    }
    
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationManager()
            checkLocationAuthorization()
        }
        else {
            // alerta!
        }
    }
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func checkLocationAuthorization() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            self.mapView.isMyLocationEnabled = true
            centerViewOnUserLocation()
            break
        case .denied:
            break
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
            break
        case .restricted:
            break
        case .authorizedAlways:
            self.mapView.isMyLocationEnabled = true
            centerViewOnUserLocation()
            break
        default:
            break
        }
    }
    
    func centerViewOnUserLocation() {
        if let location = locationManager.location?.coordinate {
            let camera = GMSCameraPosition.camera(
                withLatitude: location.latitude,
                longitude: location.longitude,
                zoom: 16
            )
            self.mapView.camera = camera
        }
    }
    
    func centerViewOnArgentina() {
        let camera = GMSCameraPosition.camera(
            withLatitude: -42.265375,
            longitude: -65.244208,
            zoom: 4
        )
        self.mapView.camera = camera
    }
    
    func centerViewOnPlaceSelected(place: GMSPlace) {
        let camera = GMSCameraPosition.camera(
            withLatitude: place.coordinate.latitude,
            longitude: place.coordinate.longitude,
            zoom: 16
        )
        self.mapView.camera = camera
        
        self.gmsMarker?.map = nil
        let initialLocation = CLLocationCoordinate2DMake(place.coordinate.latitude, place.coordinate.longitude)
        self.gmsMarker = GMSMarker(position: initialLocation)
        self.gmsMarker?.map = self.mapView
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "profileAddressDetailSegue" {
            self.addressDetailController = segue.destination as? ProfileAddressDetailController
        }
    }
}


extension ProfileAddressController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // do-nothing
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        checkLocationAuthorization()
    }
}


extension ProfileAddressController: GMSMapViewDelegate {
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        mapView.delegate = self
        self.showGroupDetailOverlay(height: Float(120.0))
        return true
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        self.hideGroupDetailOverlay()
    }
    
    func showGroupDetailOverlay(height: Float) {
        addressHeightConstraint.constant = CGFloat(height)
        self.view.layoutIfNeeded()
        addressViewConstraint.constant = -addressView.frame.height
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    func hideGroupDetailOverlay() {
        addressViewConstraint.constant = 0
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }
}


extension ProfileAddressController: GMSAutocompleteViewControllerDelegate {
    
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        self.centerViewOnPlaceSelected(place: place)
        self.addressDetailController?.populateModel(place: place)
        self.showGroupDetailOverlay(height: Float(120.0))
        dismiss(animated: true, completion: nil)
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}


class ProfileAddressDetailController: UIViewController {
    
    @IBOutlet var address: UILabel!
    
    var place: GMSPlace?
    var province: String?
    var locality: String?
    var street: String?
    var streetNumber: String?
    var floor: String?
    var department: String?
    var postalCode: String?
    var latitude: String?
    var longitude: String?
    
    func populateModel(place: GMSPlace) {
        self.place = place
        
        // Province
        self.province = self.findType(type: "administrative_area_level_1")?.shortName
        
        // Locality
        if let localityGMS = self.findType(type: (self.province == "CABA" ? "sublocality" : "locality")) {
            self.locality = localityGMS.name
        }
        else {
            self.locality = self.findType(type: "administrative_area_level_2")?.name
        }
        
        // Street
        self.street = self.findType(type: "route")?.shortName
        
        // Street Number
        if let streetNumberGMS = self.findType(type: "street_number"), !streetNumberGMS.name.contains("-") {
            self.streetNumber = streetNumberGMS.name
        }
        
        // Postal Code
        if let postalCodeGMS = self.findType(type: "postal_code") {
            self.postalCode = postalCodeGMS.shortName?.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789").inverted)
        }
       
        // LatLang
        self.latitude = self.place?.coordinate.latitude.description
        self.longitude = self.place?.coordinate.longitude.description
        
        var addressList: [String] = []
        if let street = self.street, let streetNumber = self.streetNumber {
            addressList.append("\(street) \(streetNumber)")
        }
        else if let street = self.street {
            addressList.append(street)
        }
        if let locality = self.locality {
            addressList.append(locality)
        }
        if let province = self.province {
            addressList.append(province)
        }
        if let postalCode = self.postalCode {
            addressList.append("CP: \(postalCode)")
        }
        
        self.address.text = addressList.joined(separator: ", ")
    }
    
    func findType(type: String!) -> GMSAddressComponent? {
        return self.place?.addressComponents?.first(where: { $0.types.contains(type) }) ?? nil
    }
}
