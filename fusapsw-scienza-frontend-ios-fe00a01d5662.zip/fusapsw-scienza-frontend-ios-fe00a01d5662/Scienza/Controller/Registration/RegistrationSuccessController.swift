//
//  UserRegisterOkController.swift
//  Scienza
//
//  Created by Matias M. Gonzalez on 7/25/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit


class RegistrationSuccessController: UIViewController {
    
    @IBOutlet var avatar: UIImageView!
    
    var configuration: Configuration!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.populateModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.avatar.image = configuration.user?.avatarAsImage()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "profileSegue" {
            let destination = segue.destination as! ProfileController
            destination.loggedIn = false
            destination.configuration = self.configuration
            destination.user = self.configuration.user
        }
    }
}
