//
//  ayuda.swift
//  Scienza
//
//  Created by Kender on 29/5/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit


class HelpController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func btnAceptarAyuda(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
