//
//  ProfileAvatarController.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/28/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit


class ProfileAvatarController: UIViewController {

    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var fullName: UILabel!
    @IBOutlet weak var fullDocumentNumber: UILabel!
}
