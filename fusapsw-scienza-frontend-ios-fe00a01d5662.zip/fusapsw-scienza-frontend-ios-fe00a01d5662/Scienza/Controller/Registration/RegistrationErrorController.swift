//
//  AltaErronea.swift
//  Scienza
//
//  Created by Kender on 19/5/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class RegistrationErrorController: UIViewController {

    @IBOutlet var tableView: UITableView!
    
    var registrationCell: RegistrationCell?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
    }
    
    @IBAction func btnRegistrateError(_ sender: UIButton) {
        self.registrateError()
    }
    
    func registrateError() {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! RegistrationErrorCell
        if(!self.validate(cell)) {
            return
        }
        
        let data = RegistrationErrorRequest()
        data.documentNumber = Int((registrationCell?.documentNumber.text)!)
        data.sapId = Int((registrationCell?.sapId.text)!)
        data.password = registrationCell?.password.text!
        data.firstName = cell.firstName.text!.trimmingCharacters(in: .whitespaces)
        data.lastName = cell.lastName.text!.trimmingCharacters(in: .whitespaces)
        data.telephone = cell.telephone.text!.trimmingCharacters(in: .whitespaces)
        data.email = cell.email.text!.trimmingCharacters(in: .whitespaces)
        
        SVProgressHUD.show()
        let endpoint = Endpoint.registrationError
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<RegistrationErrorResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                        self.registrateError()
                    }))
                    self.present(alert, animated: true, completion: nil)
                }
                else {
                    let alert = UIAlertController(title: "", message: data.body?.message!, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                        self.performSegue(withIdentifier: "unwindLogin", sender: self)
                    }))
                    self.present(alert, animated: true, completion: nil)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.registrateError()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate(_ cell: RegistrationErrorCell) -> Bool {
        let firstName = cell.firstName.text!.trimmingCharacters(in: .whitespaces)
        let lastName = cell.lastName.text!.trimmingCharacters(in: .whitespaces)
        let telephone = cell.telephone.text!.trimmingCharacters(in: .whitespaces)
        let email = cell.email.text!.trimmingCharacters(in: .whitespaces)
        if(firstName.count == 0 || lastName.count == 0 || telephone.count == 0 || email.count == 0) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }
        return false
    }
}


extension RegistrationErrorController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "registrationErrorCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? RegistrationErrorCell
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
