//
//  CoordinationRejectController.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/3/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import IQKeyboardManagerSwift


class CoordinationRejectController: UIViewController {
    
    
    @IBOutlet var orderNumber: UILabel!
    @IBOutlet var tableView: UITableView!
    
    var orderDetail: OrderDetail!
    var coordination: Coordination?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.orderNumber.text = String()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        IQKeyboardManager.shared.enable = false
        self.populateModel()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = true
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
        self.tableView.reloadData()
        SVProgressHUD.dismiss()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "proposalFinishSegue" {
            let destination = segue.destination as! CoordinationFinishController
            destination.accepted = false
            destination.changePharmacy = false
        }
    }
    
    @IBAction func rejectProposal(_ sender: UIButton) {
        self.rejectCoordination()
    }
    
    func rejectCoordination() {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! CoordinationRejectCell
        let data = CoordinationRequest()
        data.orderId = self.orderDetail.id
        data.proposalId = self.coordination?.proposalId
        data.accepted = false
        data.changePharmacy = false
        data.addressCode = nil
        data.dateCode = nil
        data.shiftCode = nil
        data.paymentCode = nil
        data.rejectComment = cell.rejectComment.text.trimmingCharacters(in: .whitespaces)
        
        if data.rejectComment?.count == 0 {
            let alert = UIAlertController(title: "", message: Messages.proposalRejectComment, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        SVProgressHUD.show()
        let endpoint = Endpoint.coordinationResult
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data)
        AF.request(request).responseObject { (response: DataResponse<CoordinationResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in self.performSegue(withIdentifier: "unwindOrderDetailSegue", sender: nil)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.performSegue(withIdentifier: "proposalFinishSegue", sender: self)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.rejectCoordination()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}


extension CoordinationRejectController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.coordination == nil) ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cellIdentifier = "coordinationRejectCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationRejectCell
            cell?.message.text = "\((SesionManager.getActiveUser()?.firstName)!), indique cual fue el motivo de su rechazo."
            return cell!
        default:
            let cellIdentifier = "coordinationConfirmCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0:
            return 400.0
        case 1:
            return 280.0
        default:
            return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
