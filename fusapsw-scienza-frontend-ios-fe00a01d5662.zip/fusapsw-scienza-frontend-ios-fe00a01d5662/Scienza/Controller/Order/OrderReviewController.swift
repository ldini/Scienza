//
//  OrderReviewController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderReviewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var orderDetail: OrderDetail?
    var sections: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.sections = []
        if (self.orderDetail?.allowUploads)! {
            self.sections.append("DOCUMENTATION")
        }
        self.sections.append("DRUG")
        self.tableView.reloadData()
    }
}


extension OrderReviewController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.orderDetail == nil) ? 0 : self.sections.count
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch self.sections[section] {
            case "DOCUMENTATION":
                return 1
            case "DRUG":
                return self.orderDetail?.drugList?.count ?? 0
            default:
                return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch self.sections[indexPath.section] {
            case "DOCUMENTATION":
                let cellIdentifier = "orderMessageCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
                return cell
            default:
                let cellIdentifier = "orderDrugCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugCell
                let drug = (self.orderDetail?.drugList![indexPath.row])!
                cell?.amount.text = String(describing: drug.amount!)
                cell?.name.text = drug.name
                cell?.laboratory.text = drug.laboratory
                return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch self.sections[section] {
            case "DRUG":
                let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 60))
                let label = UILabel(frame: CGRect(x: 15, y: 30, width: view.frame.size.width-30, height: 30))
                returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                returnedView.addSubview(label)
                label.font = UIFont(name: "Roboto-Medium", size: 14.0)
                label.text = "MEDICAMENTOS"
                label.adjustsFontSizeToFitWidth = true
                label.minimumScaleFactor = 0.5
                label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
                return returnedView
            default:
                return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch self.sections[section] {
            case "DRUG":
                return 60.0
            default:
                return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch self.sections[indexPath.section] {
            case "DOCUMENTATION":
                return 120.0
            default:
                return 60.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
