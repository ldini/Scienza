//
//  OrderPendingDrugController.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/20/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderPendingDrugController: UIViewController {
    
    @IBOutlet var icon: UIImageView!
    @IBOutlet var status: UILabel!
    @IBOutlet var orderNumber: UILabel!
    @IBOutlet var tableView: UITableView!
    
    var orderId: Int!
    var orderDetail: OrderDetail?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.icon.isHidden = true
        self.status.text = String()
        self.orderNumber.text = String()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.icon.isHidden = false
        self.icon.image = UIImage(named: UIConstant.instance.orderImageFor(statusCode: (self.orderDetail?.statusCode)!))
        self.status.text = self.orderDetail?.status!.uppercased()
        self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
        self.tableView.reloadData()
    }
}


extension OrderPendingDrugController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.orderDetail == nil) ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.orderDetail?.drugList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "orderDrugCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugCell
        let drug = (self.orderDetail?.drugList![indexPath.row])!
        cell?.amount.text = String(describing: drug.amount!)
        cell?.name.text = drug.name
        cell?.laboratory.text = drug.laboratory
        return cell!
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 120))
        let label1 = UILabel(frame: CGRect(x: 15, y: 20, width: view.frame.size.width-30, height: 60))
        let label2 = UILabel(frame: CGRect(x: 15, y: 90, width: view.frame.size.width-30, height: 30))
        returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        returnedView.addSubview(label1)
        returnedView.addSubview(label2)
        
        label1.font = UIFont(name: "Roboto-Light", size: 13.0)
        label1.text = "\((SesionManager.getActiveUser()?.firstName)!), los siguientes medicamentos están pendientes de coordinación:"
        label1.adjustsFontSizeToFitWidth = true
        label1.numberOfLines = 2
        label1.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
        
        label2.font = UIFont(name: "Roboto-Medium", size: 14.0)
        label2.text = "MEDICAMENTOS"
        label2.adjustsFontSizeToFitWidth = true
        label2.minimumScaleFactor = 0.5
        label2.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
        return returnedView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 60))
        let label1 = UILabel(frame: CGRect(x: 35, y: 20, width: view.frame.size.width-70, height: 60))
        returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        returnedView.addSubview(label1)
        
        label1.font = UIFont(name: "Roboto-Light", size: 13.0)
        label1.text = "A la brevedad estará recibiendo novedades."
        label1.adjustsFontSizeToFitWidth = true
        label1.minimumScaleFactor = 0.5
        label1.textAlignment = .center
        label1.numberOfLines = 2
        label1.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
        return returnedView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 120.0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 60.0
    }
}
