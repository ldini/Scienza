//
//  CoordinationDateController.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/2/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class CoordinationDateController: UIViewController {
    
    @IBOutlet var status: UILabel!
    @IBOutlet var orderNumber: UILabel!
    @IBOutlet var tableView: UITableView!
    
    
    var orderDetail: OrderDetail!
    var coordination: Coordination?
    var proposalAddress: ProposalAddress?
    var proposalDate: ProposalDate?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.status.text = String()
        self.orderNumber.text = String()
        let headerNib = UINib.init(nibName: "CoordinationDrugView", bundle: Bundle.main)
        self.tableView.register(headerNib, forHeaderFooterViewReuseIdentifier: "CoordinationDrugView")
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        self.status.text = self.orderDetail?.status!.uppercased()
        self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
        self.tableView.reloadData()
        SVProgressHUD.dismiss()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "proposalPaymentSegue" {
            let destination = segue.destination as! CoordinationPaymentController
            destination.orderDetail = self.orderDetail
            destination.coordination = self.coordination
            destination.coordination?.showDrugs = false
            destination.proposalAddress = self.proposalAddress
            destination.proposalDate = self.proposalDate
        }
        if segue.identifier == "proposalSummarySegue" {
            let destination = segue.destination as! CoordinationSummaryController
            destination.orderDetail = self.orderDetail
            destination.coordination = self.coordination
            destination.coordination?.showDrugs = false
            destination.proposalAddress = self.proposalAddress
            destination.proposalDate = self.proposalDate
            destination.proposalPayment = nil
        }
        if segue.identifier == "proposalRejectSegue" {
            let destination = segue.destination as! CoordinationRejectController
            destination.orderDetail = self.orderDetail
            destination.coordination = self.coordination
            destination.coordination?.showDrugs = false
        }
    }
    
    @IBAction func rejectProposal(_ sender: UIButton) {
        self.performSegue(withIdentifier: "proposalRejectSegue", sender: self)
    }
    
    @IBAction func nextProposal(_ sender: UIButton) {
        if self.proposalDate == nil {
            let alert = UIAlertController(title: "", message: Messages.proposalError, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if (self.coordination?.hasPayment())! {
            self.performSegue(withIdentifier: "proposalPaymentSegue", sender: self)
        }
        else {
            self.performSegue(withIdentifier: "proposalSummarySegue", sender: self)
        }
    }
}


extension CoordinationDateController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.coordination == nil) ? 0 : 5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return self.coordination?.rows().count ?? 0
        case 1:
            return 1
        case 2:
            return 1
        case 3:
            return (self.proposalAddress?.dateList?.count)!
        case 4:
            return 1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cellIdentifier = "orderDrugCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugCell
            let drug = self.coordination!.rows()[indexPath.row]
            cell?.amount.text = String(describing: drug.amount!)
            cell?.name.text = drug.name
            cell?.laboratory.text = drug.laboratory
            return cell!
        case 1:
            let cellIdentifier = "coordinationSelectedCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSelectedCell
            cell?.subtitle.text = self.proposalAddress!.address
            cell?.subtitle2.text = self.proposalAddress!.pharmacy ?? String()
            return cell!
        case 2:
            let cellIdentifier = "coordinationProgressCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationProgressCell
            if (self.coordination?.hasPayment())! {
                cell?.progress.image = UIImage(named: "three_date")
            }
            else {
                cell?.progress.image = UIImage(named: "two_date")
            }
            return cell!
        case 3:
            let cellIdentifier = "coordinationOptionCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationOptionCell
            let proposal = self.proposalAddress?.dateList![indexPath.row]
            cell?.title.text = proposal?.dateText!
            cell?.subtitle.text = proposal?.shiftText!
            cell?.view.layer.cornerRadius = 40
            cell?.view.layer.masksToBounds = true
            cell?.selectionStyle = UITableViewCell.SelectionStyle.none
            return cell!
        default:
            let cellIdentifier = "coordinationSegueCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSegueCell
            cell?.message.text = "\((SesionManager.getActiveUser()?.firstName)!), si ninguna de las opciones es de su preferencia por favor, rechace la propuesta."
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 3:
            self.proposalDate = self.proposalAddress?.dateList![indexPath.row]
        default:
            break
        }
    }
    
    func tableView(_ tableView: UITableView, willDeselectRowAt indexPath: IndexPath) -> IndexPath? {
        switch indexPath.section {
        case 3:
            self.proposalDate = nil
            break
        default:
            break
        }
        return indexPath
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch section {
        case 0:
            let header = "CoordinationDrugView"
            let drugView = tableView.dequeueReusableHeaderFooterView(withIdentifier: header) as! CoordinationDrugView
            drugView.detailButton.addTarget(self, action: #selector(handleOpenCloseDetail), for: .touchUpInside)
            drugView.detailButton.tag = section
            return drugView
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        switch section {
        case 2:
            let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 30))
            let label = UILabel(frame: CGRect(x: 15, y: 0, width: view.frame.size.width-30, height: 30))
            returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            returnedView.addSubview(label)
            label.font = UIFont(name: "Roboto-Regular", size: 13.0)
            label.text = "FECHA Y HORA"
            label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
            if (self.coordination?.hasPayment())! {
                label.textAlignment = NSTextAlignment.center
            }
            else {
                label.textAlignment = NSTextAlignment.right
            }
            return returnedView
        default:
            return nil
        }
    }
    
    @objc func handleOpenCloseDetail(button: UIButton) {
        let section = button.tag
        if self.coordination!.showDrugs {
            let indexPaths = Array(0 ..< self.coordination!.rows().count).map { IndexPath(item: $0, section: section) }
            self.coordination!.showDrugs = !self.coordination!.showDrugs
            self.tableView.deleteRows(at: indexPaths, with: .bottom)
            button.setTitle("Ver más", for: .normal)
        }
        else {
            self.coordination!.showDrugs = !self.coordination!.showDrugs
            let indexPaths = Array(0 ..< self.coordination!.rows().count).map { IndexPath(item: $0, section: section) }
            self.tableView.insertRows(at: indexPaths, with: .top)
            button.setTitle("Ver menos", for: .normal)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            return 60.0
        default:
            return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 60.0
        case 1:
            return 50.0
        case 2:
            return 60.0
        case 3:
            return 90.0
        case 4:
            return 140.0
        default:
            return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            return 15.0
        case 1:
            return 15.0
        case 2:
            return 40.0
        default:
            return 0.1
        }
    }
}
