//
//  CoordinationFinishController.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/4/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit


class CoordinationFinishController: UIViewController {
    

    @IBOutlet var icon: UIImageView!
    @IBOutlet var titleIcon: UILabel!
    @IBOutlet var message: UILabel!
    
    var accepted: Bool!
    var changePharmacy: Bool!
    
    
    override func viewDidLoad() {
        if self.accepted {
            self.icon.image = UIImage(named: "coordination_success")
            self.titleIcon.text = "¡Su coordinación fue exitosa!"
            self.message.text = "\((SesionManager.getActiveUser()?.firstName)!), recuerde presentar su receta original, credencial y DNI.\nEn caso de requerir su receta en forma digital será informado."
        }
        else if self.changePharmacy {
            self.icon.image = UIImage(named: "coordination_interrupted")
            self.titleIcon.text = "Recoordinando pedido."
            self.message.text = "\((SesionManager.getActiveUser()?.firstName)!), en breve estará recibiendo una nueva propuesta para coordinar su pedido considerando la farmacia elegida por usted."
        }
        else {
            self.icon.image = UIImage(named: "coordination_reject")
            self.titleIcon.text = "Coordinación rechazada."
            self.message.text = "Gracias por su comentario. A la brevedad estará recibiendo novedades."
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
