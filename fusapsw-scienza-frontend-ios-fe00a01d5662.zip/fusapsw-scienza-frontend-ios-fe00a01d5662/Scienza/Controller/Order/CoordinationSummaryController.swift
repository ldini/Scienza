//
//  CoordinationSummaryController.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/3/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class CoordinationSummaryController: UIViewController {
    
    
    @IBOutlet var orderNumber: UILabel!
    @IBOutlet var tableView: UITableView!
    
    var orderDetail: OrderDetail!
    var coordination: Coordination?
    var proposalAddress: ProposalAddress?
    var proposalDate: ProposalDate?
    var proposalPayment: ProposalPayment?
    var proposalPharmacy: ProposalPharmacy?
    var sections: [String] = []
    var proposals: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.orderNumber.text = String()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        SVProgressHUD.show()
        self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
        if self.coordination != nil {
            self.sections.append("DRUGS")
            self.sections.append("PROPOSALS")
            if proposalPharmacy != nil {
                self.proposals.append("PHARMACY")
                self.proposals.append("LEGEND")
            }
            else {
                self.proposals.append("ADDRESS")
                self.proposals.append("DATE")
                if (self.coordination?.hasPayment())! {
                    self.proposals.append("PAYMENT")
                }
            }
            self.sections.append("FINISH")
        }
        self.tableView.reloadData()
        SVProgressHUD.dismiss()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "proposalFinishSegue" {
            let destination = segue.destination as! CoordinationFinishController
            if self.proposalPharmacy == nil {
                destination.accepted = true
                destination.changePharmacy = false
            }
            else {
                destination.accepted = false
                destination.changePharmacy = true
            }
        }
    }
    
    @IBAction func confirmProposal(_ sender: UIButton) {
        self.confirmCoordination()
    }
    
    func confirmCoordination() {
        SVProgressHUD.show()
        
        let data = CoordinationRequest()
        data.orderId = self.orderDetail.id
        data.proposalId = self.coordination?.proposalId
        if self.proposalPharmacy == nil {
            data.accepted = true
            data.changePharmacy = false
            data.addressCode = self.proposalAddress?.addressCode
            data.dateCode = self.proposalDate?.dateCode
            data.shiftCode = self.proposalDate?.shiftCode
            data.paymentCode = self.proposalPayment?.paymentCode
            data.rejectComment = nil
        }
        else {
            data.accepted = false
            data.changePharmacy = true
            data.rejectComment = self.proposalPharmacy?.id
        }
        
        let endpoint = Endpoint.coordinationResult
        let request = HttpRequest.instance.createPostRequest(endpoint: endpoint, data: data, timeout: 30)
        AF.request(request).responseObject { (response: DataResponse<CoordinationResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in self.performSegue(withIdentifier: "unwindOrderDetailSegue", sender: nil)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.performSegue(withIdentifier: "proposalFinishSegue", sender: self)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.confirmCoordination()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}


extension CoordinationSummaryController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch self.sections[section] {
        case "DRUGS":
            return (self.coordination?.drugList?.count)!
        case "PROPOSALS":
            return self.proposals.count
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch self.sections[indexPath.section] {
        case "DRUGS":
            let cellIdentifier = "orderDrugCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugCell
            let drug = (self.coordination?.drugList![indexPath.row])!
            cell?.amount.text = String(describing: drug.amount!)
            cell?.name.text = drug.name
            return cell!
        case "PROPOSALS":
            switch self.proposals[indexPath.row] {
            case "ADDRESS":
                let cellIdentifier = "coordinationAddressSelectedCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSelectedCell
                cell?.subtitle.text = self.proposalAddress!.address
                cell?.subtitle2.text = self.proposalAddress!.pharmacy ?? String()
                return cell!
            case "DATE":
                let cellIdentifier = "coordinationDateSelectedCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSelectedCell
                cell?.title.text = self.proposalDate?.dateText
                cell?.subtitle.text = self.proposalDate?.shiftText
                return cell!
            case "PAYMENT":
                let cellIdentifier = "coordinationPaymentSelectedCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSelectedCell
                cell?.title.text = "$ \(String(format: "%.2f", arguments: [self.coordination!.payment!]))"
                cell?.subtitle.text = self.proposalPayment?.paymentText
                return cell!
            case "PHARMACY":
                let cellIdentifier = "coordinationAddressSelectedCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationSelectedCell
                cell?.subtitle.text = self.proposalPharmacy!.address
                cell?.subtitle2.text = self.proposalPharmacy!.name ?? String()
                return cell!
            case "LEGEND":
                let cellIdentifier = "coordinationLegendCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CoordinationLegendCell
                cell?.message.text = "\((SesionManager.getActiveUser()?.firstName)!), cuando presione \"CONTINUAR\" Scienza Móvil calculará la próxima fecha de entrega posible para la farmacia elegida."
                return cell!
            default:
                let cell = tableView.dequeueReusableCell(withIdentifier: "", for: indexPath)
                return cell
            }
        default:
            let cellIdentifier = "coordinationConfirmCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch self.sections[section] {
        case "DRUGS":
            let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 60))
            let label = UILabel(frame: CGRect(x: 15, y: 30, width: view.frame.size.width-30, height: 30))
            returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            returnedView.addSubview(label)
            label.font = UIFont(name: "Roboto-Medium", size: 14.0)
            label.text = "MEDICAMENTOS"
            label.adjustsFontSizeToFitWidth = true
            label.minimumScaleFactor = 0.5
            label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
            return returnedView
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        switch self.sections[section] {
        case "DRUGS":
            let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 15.0))
            returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            return returnedView
        case "PROPOSALS":
            let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 25.0))
            returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            return returnedView
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch self.sections[section] {
        case "DRUGS":
            return 60.0
        default:
            return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch self.sections[indexPath.section] {
        case "DRUGS":
            return 45.0
        case "PROPOSALS":
            switch self.proposals[indexPath.row] {
                case "LEGEND":
                    return 120.0
                default:
                    return 50.0
            }
        case "FINISH":
            return 100.0
        default:
            return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        switch self.sections[section] {
        case "DRUGS":
            return 15.0
        case "PROPOSALS":
            return 25.0
        default:
            return 0.1
        }
    }
}

