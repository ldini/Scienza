//
//  OrderController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/22/18.
//  Copyright © 2018 fusap. All rights reserved.
//
import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var noResultsView: NoResultsView!
    
    var orderList: [Order]! = []
    var search: Bool = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.tableView.isHidden = true
        self.noResultsView.isHidden = true
        self.populateModel(fromId: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel(fromId: Int?) {
        SVProgressHUD.show()
        let endpoint = (fromId == nil) ? Endpoint.orderList : String(format: Endpoint.orderFromList, fromId!)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<OrderResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.populateModel(fromId: fromId)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else if data.body!.count == 0 && self.orderList.count == 0 {
                    self.noResultsView.isHidden = false
                    self.tableView.isHidden = true
                }
                else {
                    self.insertOrderList(orderList: data.body!, animated: fromId != nil)
                    self.noResultsView.isHidden = true
                    self.tableView.isHidden = false
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel(fromId: fromId)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func insertOrderList(orderList: [Order], animated: Bool!) {
        self.orderList.insert(contentsOf: orderList, at: self.orderList.count)
        self.tableView.reloadData()
        if orderList.count < 5 {
            self.search = false
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "orderDetailSegue" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let order = self.orderList[indexPath.row]
                let destination = segue.destination as! OrderDetailController
                destination.orderId = order.orderNumber!
            }
        }
    }
}


extension OrderController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.orderList.count
    }
 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let order = self.orderList[indexPath.row]
        if order.coordinable! {
            let cellIdentifier = "orderCoordinationCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCell
            cell?.status.text = order.status!.uppercased()
            cell?.orderNumber.text = String(describing: order.orderNumber!)
            cell?.message.text = "\((SesionManager.getActiveUser()?.firstName)!), tiene disponible una nueva entrega para coordinar."
            cell?.backgroundColor = (indexPath.row % 2 == 0) ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : #colorLiteral(red: 0.9137254902, green: 0.9137254902, blue: 0.9137254902, alpha: 1)
            return cell!
        }
        else if order.deliveryDate == nil {
            let cellIdentifier = "orderReviewCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCell
            cell?.status.text = order.status!.uppercased()
            cell?.orderNumber.text = String(describing: order.orderNumber!)
            cell?.backgroundColor = (indexPath.row % 2 == 0) ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : #colorLiteral(red: 0.9137254902, green: 0.9137254902, blue: 0.9137254902, alpha: 1)
            return cell!
        }
        else {
            let cellIdentifier = "orderCoordinatedCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCell
            cell?.date.text = order.deliveryDate ?? String()
            cell?.status.text = order.status!.uppercased()
            cell?.orderNumber.text = String(describing: order.orderNumber!)
            cell?.backgroundColor = (indexPath.row % 2 == 0) ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : #colorLiteral(red: 0.9137254902, green: 0.9137254902, blue: 0.9137254902, alpha: 1)
            return cell!
        }
    }
   
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row + 1 == self.orderList.count {
            if let _ = self.tableView.indexPathsForVisibleRows?.firstIndex(of: indexPath) {
                if self.search {
                    let order = self.orderList[indexPath.row]
                    self.populateModel(fromId: order.orderNumber!)
                }
            }
            else if let _ = self.tableView.indexPathsForVisibleRows?.firstIndex(of: IndexPath(row: indexPath.row-1, section: indexPath.section)) {
                if self.search {
                    let order = self.orderList[indexPath.row]
                    self.populateModel(fromId: order.orderNumber!)
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "orderDetailSegue", sender: self)
    }
 
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let order = self.orderList[indexPath.row]
        if !(order.coordinable!) {
            return 135.0
        }
        else {
            return 170.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}
