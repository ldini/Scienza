//
//  OrderDetailSegue.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/28/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderDetailController: UIViewController {

    @IBOutlet var icon: UIImageView!
    @IBOutlet var status: UILabel!
    @IBOutlet var orderNumber: UILabel!
    @IBOutlet var orderReviewView: UIView!
    @IBOutlet var orderDeliveryView: UIView!
    @IBOutlet var orderDeliveryMultipleView: UIView!
    
    var orderId: Int!
    var orderDetail: OrderDetail?
    var delivery: Delivery?
    var orderReviewController: OrderReviewController?
    var orderDeliveryController: OrderDeliveryController?
    var orderDeliveryMultipleController: OrderDeliveryMultipleController?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.icon.isHidden = true
        self.status.text = String()
        self.orderNumber.text = String()
        self.orderReviewView.isHidden = true
        self.orderDeliveryView.isHidden = true
        self.orderDeliveryMultipleView.isHidden = true
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        if self.delivery != nil {
            self.icon.isHidden = false
            self.icon.image = UIImage(named: UIConstant.instance.orderImageFor(statusCode: (self.orderDetail?.statusCode)!))
            self.status.text = self.orderDetail?.status!.uppercased()
            self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
            self.orderDeliveryView.isHidden = false
            self.orderDeliveryController?.orderDetail = self.orderDetail
            self.orderDeliveryController?.delivery = self.delivery
            self.orderDeliveryController?.populateModel()
            return
        }
        SVProgressHUD.show()
        let endpoint = String(format: Endpoint.orderDetail, self.orderId)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<OrderDetailResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { action in
                        self.navigationController?.popViewController(animated: true)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.orderDetail = data.body!
                    self.icon.isHidden = false
                    self.icon.image = UIImage(named: UIConstant.instance.orderImageFor(statusCode: (self.orderDetail?.statusCode)!))
                    self.status.text = self.orderDetail?.status!.uppercased()
                    self.orderNumber.text = "Pedido #\(self.orderDetail?.number! ?? 0)"
                    if let order = self.orderDetail {
                        if order.coordinable! {
                            self.orderDeliveryMultipleView.isHidden = false
                            self.orderDeliveryMultipleController?.orderDetail = order
                            self.orderDeliveryMultipleController?.populateModel()
                        }
                        else if order.statusCode == "REVISION" || order.statusCode == "AUDITORIA" {
                            self.orderReviewView.isHidden = false
                            self.orderReviewController?.orderDetail = order
                            self.orderReviewController?.populateModel()
                        }
                        else if !(order.partial!) {
                            self.orderDeliveryView.isHidden = false
                            self.orderDeliveryController?.orderDetail = order
                            self.orderDeliveryController?.delivery = order.deliveryList![0]
                            self.orderDeliveryController?.populateModel()
                        }
                        else {
                            self.orderDeliveryMultipleView.isHidden = false
                            self.orderDeliveryMultipleController?.orderDetail = order
                            self.orderDeliveryMultipleController?.populateModel()
                        }
                        
                        let viewControllers = self.navigationController?.viewControllers
                        if let orderController = viewControllers?.first(where: { $0.isKind(of: OrderController.self) }) as? OrderController {
                            if let index = orderController.orderList.firstIndex(where: { $0.id == order.id }) {
                                let orderAux = Order()
                                orderAux.id = order.id
                                orderAux.type = order.type
                                orderAux.status = order.status
                                orderAux.statusCode = order.statusCode
                                orderAux.orderNumber = order.number
                                orderAux.deliveryDate = order.date
                                orderAux.partial = order.partial
                                orderAux.coordinable = order.coordinable
                                orderAux.allowUploads = order.allowUploads
                                orderController.orderList[index] = orderAux
                            }
                        }
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "orderReviewSegue" {
            self.orderReviewController = segue.destination as? OrderReviewController
        }
        if segue.identifier == "orderDeliverySegue" {
            self.orderDeliveryController = segue.destination as? OrderDeliveryController
        }
        if segue.identifier == "orderMultipleDeliverySegue" {
            self.orderDeliveryMultipleController = segue.destination as? OrderDeliveryMultipleController
        }
    }
    
    @IBAction func unwindOrderDetail(segue: UIStoryboardSegue!) {
        self.orderDetail = nil
        self.icon.isHidden = true
        self.status.text = String()
        self.orderNumber.text = String()
        self.orderReviewView.isHidden = true
        self.orderDeliveryView.isHidden = true
        self.orderDeliveryMultipleView.isHidden = true
        self.populateModel()
    }
}
