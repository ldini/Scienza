//
//  OrderDeliveryController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderDeliveryController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var orderDetail: OrderDetail?
    var delivery: Delivery?
    var location: Location?
    var sections: [String] = []
    var sectionDrugStart: Int!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let headerNib = UINib.init(nibName: "DeliveryDrugView", bundle: Bundle.main)
        self.tableView.register(headerNib, forHeaderFooterViewReuseIdentifier: "DeliveryDrugView")
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.sections = []
        self.sections.append("DELIVERY")
        if (self.delivery?.showLocation)! {
            self.populateLocation()
        }
        else {
            self.populateDelivery()
        }
    }
    
    func populateDelivery() {
        self.sections.append("TITLE")
        self.sectionDrugStart = self.sections.count
        self.sections.append(contentsOf: Array(0..<(self.delivery?.drugList)!.count).map { _ in "DRUG" })
        self.sections.append("ADDRESS")
        self.sections.append("DATE")
        if (self.delivery?.payment ?? Float(0)) > Float(0) {
            self.sections.append("PAYMENT")
        }
        self.tableView.reloadData()
    }
    
    /* solo visualizo cuando termina en forma exitosa */
    func populateLocation() {
        SVProgressHUD.show()
        let endpoint = String(format: Endpoint.orderLocation, (self.delivery?.number)!)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<OrderLocationResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code == 0 {
                    self.location = data.body!
                    self.sections.append("LOCATION")
                }
                self.populateDelivery()
                break
            case .failure:
                self.populateDelivery()
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}


extension OrderDeliveryController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.delivery == nil) ? 0 : self.sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch self.sections[section] {
            case "DELIVERY":
                return 1
            case "LOCATION":
                return 1
            case "DRUG":
                return (self.delivery?.drugList![section-self.sectionDrugStart].rows().count)!
            case "ADDRESS","DATE","PAYMENT":
                return 1
            default:
                return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch self.sections[indexPath.section] {
            case "DELIVERY":
                let cellIdentifier = "orderDeliveryCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDeliveryCell
                cell?.number.text = String(describing: self.delivery!.number!)
                cell?.status.text = self.delivery?.status?.uppercased()
                return cell!
            case "LOCATION":
                let cellIdentifier = "orderLocationCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderLocationCell
                cell?.arrivalTime.text = self.location?.arrivalTime!
                cell?.distance.text = self.location?.distance!
                cell?.distributor.text = self.location?.distributor!
                cell?.patent.text = self.location?.patent!
                return cell!
            case "DRUG":
                let cellIdentifier = "orderDrugDetailCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugDetailCell
                let data = self.delivery?.drugList![indexPath.section-self.sectionDrugStart].rows()[indexPath.row]
                cell?.label.text = data?.label
                cell?.value.text = data?.value
                return cell!
            case "ADDRESS":
                let cellIdentifier = "orderCoordinatedPharmacyCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCoordinatedCell
                cell?.icon.image = UIImage(named: "delivery_address")
                cell?.title.text = self.delivery?.address
                cell?.subtitle.text = self.delivery?.pharmacy
                return cell!
            case "DATE":
                let cellIdentifier = "orderCoordinatedDatePaymentCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCoordinatedCell
                cell?.icon.image = UIImage(named: "delivery_date")
                cell?.title.text = self.delivery?.date
                cell?.subtitle.text = self.delivery?.shift
                return cell!
            case "PAYMENT":
                let cellIdentifier = "orderCoordinatedDatePaymentCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderCoordinatedCell
                let payment = (self.delivery?.payment)!
                cell?.icon.image = UIImage(named: "delivery_payment")
                cell?.title.text = self.delivery?.paymentMethod ?? "Desconocido"
                cell?.subtitle.text = "$ \(String(format: "%.2f", arguments: [payment]))"
                return cell!
            default:
                return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch self.sections[section] {
            case "TITLE":
                let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 55))
                let label = UILabel(frame: CGRect(x: 15, y: 25, width: view.frame.size.width-30, height: 30))
                returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                returnedView.addSubview(label)
                label.font = UIFont(name: "Roboto-Medium", size: 14.0)
                label.text = "MEDICAMENTOS"
                label.adjustsFontSizeToFitWidth = true
                label.minimumScaleFactor = 0.5
                label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
                return returnedView
            case "DRUG":
                let headerIdentifier = "DeliveryDrugView"
                let drugView = tableView.dequeueReusableHeaderFooterView(withIdentifier: headerIdentifier) as! DeliveryDrugView
                let drug = (self.delivery?.drugList![section-self.sectionDrugStart])!
                drugView.amount.text = String(describing: drug.amount!)
                drugView.name.text = drug.name
                drugView.laboratory.text = drug.laboratory
                drugView.detailButton.addTarget(self, action: #selector(handleOpenCloseDetail), for: .touchUpInside)
                drugView.detailButton.tag = section
                return drugView
            case "ADDRESS":
                let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 25))
                returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                return returnedView
            default:
                return nil
        }
    }
    
    @objc func handleOpenCloseDetail(button: UIButton) {
        let section = button.tag
        let drug = (self.delivery?.drugList![section-self.sectionDrugStart])!
        if drug.showDetail {
            let indexPaths = Array(0 ..< drug.rows().count).map { IndexPath(item: $0, section: section) }
            drug.showDetail = !drug.showDetail
            self.tableView.deleteRows(at: indexPaths, with: .bottom)
            button.setTitle("Ver más", for: .normal)
        }
        else {
            drug.showDetail = !drug.showDetail
            let indexPaths = Array(0 ..< drug.rows().count).map { IndexPath(item: $0, section: section) }
            self.tableView.insertRows(at: indexPaths, with: .top)
            button.setTitle("Ver menos", for: .normal)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch self.sections[section] {
            case "TITLE":
                return 55.0
            case "DRUG":
                return 60.0
            case "ADDRESS":
                return 25.0
            default:
                return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch self.sections[indexPath.section] {
            case "DELIVERY":
                return 100.0
            case "LOCATION":
                return 150.0
            case "DRUG":
                return 35.0
            case "ADDRESS":
                return 70.0
            case "DATE","PAYMENT":
                return 70.0
            default:
                return -1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
