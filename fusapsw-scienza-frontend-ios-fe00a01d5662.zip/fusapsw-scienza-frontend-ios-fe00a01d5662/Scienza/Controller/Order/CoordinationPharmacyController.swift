//
//  CoordinationPharmacyController.swift
//  Scienza
//
//  Created by Paola Torrealba on 4/6/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import GoogleMaps
import GooglePlaces


class CoordinationPharmacyController: UIViewController {
    
    @IBOutlet var mapView: GMSMapView!
    @IBOutlet var pharmacyView: UIView!
    @IBOutlet var pharmacyViewConstraint: NSLayoutConstraint!
    @IBOutlet var pharmacyHeightConstraint: NSLayoutConstraint!
    
    var orderDetail: OrderDetail!
    var coordination: Coordination?
    var pharmacyList: [ProposalPharmacy]?
    var pharmacyDetailController: CoordinationPharmacyDetailController?
    var proposalPharmacy: ProposalPharmacy!
    var gmsMarker: GMSMarker?
    
    let locationManager = CLLocationManager()
    let gmsStyle = """
        [
            {
                "featureType": "administrative",
                "elementType": "geometry",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "poi",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "road",
                "elementType": "labels.icon",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "transit",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            }
        ]
    """
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let searchIcon = UIButton(type: .system)
        searchIcon.setImage(UIImage(named: "general_search")?.withRenderingMode(.alwaysOriginal), for: .normal)
        searchIcon.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        searchIcon.addTarget(self, action: #selector(searchPlace), for: .touchUpInside)
        self.navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: searchIcon)]
        
        self.setupGoogleMaps()
        self.centerViewOnArgentina()
        self.checkLocationServices()
        self.populateModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.2862745098, green: 0.3647058824, blue: 0.4117647059, alpha: 1)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.6352941176, green: 0, blue: 0.1137254902, alpha: 1)
    }
    
    @objc func searchPlace() {
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.tintColor = UIColor.red
        autocompleteController.delegate = self
        
        let filter = GMSAutocompleteFilter()
        filter.country = "AR"
        autocompleteController.autocompleteFilter = filter
        
        self.present(autocompleteController, animated: true, completion: nil)
    }
    
    func setupGoogleMaps() {
        self.mapView.delegate = self
        do {
            self.mapView.mapStyle = try GMSMapStyle(jsonString: gmsStyle)
        }
        catch {
            NSLog("One or more of the map styles failed to load. \(error)")
        }
    }
    
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationManager()
            checkLocationAuthorization()
        }
        else {
            // alerta!
        }
    }
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func checkLocationAuthorization() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            self.mapView.isMyLocationEnabled = true
            centerViewOnUserLocation()
            break
        case .denied:
            break
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
            break
        case .restricted:
            break
        case .authorizedAlways:
            self.mapView.isMyLocationEnabled = true
            centerViewOnUserLocation()
            break
        default:
            break
        }
    }
    
    func centerViewOnUserLocation() {
        if let location = locationManager.location?.coordinate {
            let camera = GMSCameraPosition.camera(
                withLatitude: location.latitude,
                longitude: location.longitude,
                zoom: 16
            )
            self.mapView.camera = camera
        }
    }
    
    func centerViewOnArgentina() {
        let camera = GMSCameraPosition.camera(
            withLatitude: -42.265375,
            longitude: -65.244208,
            zoom: 4
        )
        self.mapView.camera = camera
    }
    
    func centerViewOnPlaceSelected(place: GMSPlace) {
        let camera = GMSCameraPosition.camera(
            withLatitude: place.coordinate.latitude,
            longitude: place.coordinate.longitude,
            zoom: 16
        )
        self.mapView.camera = camera
        
        self.gmsMarker?.map = nil
        let initialLocation = CLLocationCoordinate2DMake(place.coordinate.latitude, place.coordinate.longitude)
        self.gmsMarker = GMSMarker(position: initialLocation)
        self.gmsMarker?.map = self.mapView
    }
    
    func populateModel() {
        SVProgressHUD.show()
        let endpoint = String(format: Endpoint.coordinationPharmacy, (self.orderDetail.id)!)
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<CoordinationPharmacyResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                        self.populateModel()
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.pharmacyList = data.body!
                    for pharmacy in self.pharmacyList! {
                        let latitude = Double(pharmacy.latitude!)
                        let longitude = Double(pharmacy.longitude!)
                        let initialLocation = CLLocationCoordinate2DMake(latitude, longitude)
                        let marker = GMSMarker(position: initialLocation)
                        let icon = UIImage(named: pharmacy.preferred! ? "mark_pharmacy_preferred" : "mark_pharmacy")
                        marker.icon = icon!.resizeTo(sizeChange: CGSize(width: 35, height: 58))
                        marker.userData = self.pharmacyList?.firstIndex(of: pharmacy)
                        marker.map = self.mapView
                    }
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.populateModel()
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "pharmacyDetailSegue" {
            self.pharmacyDetailController = segue.destination as? CoordinationPharmacyDetailController
        }
        if segue.identifier == "proposalSummarySegue" {
            let destination = segue.destination as! CoordinationSummaryController
            destination.orderDetail = self.orderDetail
            destination.coordination = self.coordination
            destination.coordination?.showDrugs = false
            destination.proposalPharmacy = self.proposalPharmacy
        }
    }
    
    @IBAction func unwindCoordinationSummary(segue: UIStoryboardSegue!) {
        let source = segue.source as? CoordinationPharmacyDetailController
        self.proposalPharmacy = source?.pharmacy
        self.performSegue(withIdentifier: "proposalSummarySegue", sender: self)
    }
}

extension CoordinationPharmacyController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // do-nothing
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        checkLocationAuthorization()
    }
}


extension CoordinationPharmacyController: GMSMapViewDelegate {
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        if let index = marker.userData as? Int {
            mapView.delegate = self
            let pharmacy = self.pharmacyList![index]
            self.pharmacyDetailController?.populateModel(pharmacy: pharmacy)
            let detailHeight = self.pharmacyDetailController?.detailStack.frame.height
            self.showGroupDetailOverlay(height: Float(180.0 + (detailHeight! - 15.0)))
        }
        return true
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        self.hideGroupDetailOverlay()
    }
    
    func showGroupDetailOverlay(height: Float) {
        pharmacyHeightConstraint.constant = CGFloat(height)
        self.view.layoutIfNeeded()
        pharmacyViewConstraint.constant = -pharmacyView.frame.height
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    func hideGroupDetailOverlay() {
        pharmacyViewConstraint.constant = 0
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }
}


extension CoordinationPharmacyController: GMSAutocompleteViewControllerDelegate {
    
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        self.centerViewOnPlaceSelected(place: place)
        dismiss(animated: true, completion: nil)
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}


class CoordinationPharmacyDetailController: UIViewController {
    
    @IBOutlet var name: UILabel!
    @IBOutlet var address: UILabel!
    @IBOutlet var detailStack: UIStackView!
    
    var pharmacy: ProposalPharmacy!
    
    
    func populateModel(pharmacy: ProposalPharmacy) {
        self.pharmacy = pharmacy
        self.name.text = pharmacy.name
        self.address.text = pharmacy.address
        
        let removedSubviews = self.detailStack.arrangedSubviews.reduce([]) { (allSubviews, subview) -> [UIView] in
            self.detailStack.removeArrangedSubview(subview)
            return allSubviews + [subview]
        }
        removedSubviews.forEach({ $0.removeFromSuperview() })
        
        for detail in pharmacy.details! {
            let label = UILabel()
            label.font = UIFont(name: "Roboto-Thin", size: 14.0)
            label.text = detail
            label.adjustsFontSizeToFitWidth = true
            label.minimumScaleFactor = 0.5
            label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
            label.textAlignment = NSTextAlignment.left
            self.detailStack.addArrangedSubview(label)
        }
        
        self.detailStack.layoutIfNeeded()
    }
}

