//
//  OrderMultipleDeliveryController.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class OrderDeliveryMultipleController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var orderDetail: OrderDetail?
    var sections: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.sections = []
        if((self.orderDetail?.coordinable)!) {
            self.sections.append("COORDINATION")
        }
        if (self.orderDetail?.drugList?.count)! > 0 {
            self.sections.append("PENDING")
            self.tableView.backgroundColor = #colorLiteral(red: 0.9529411765, green: 0.9529411765, blue: 0.9529411765, alpha: 1)
        }
        if (self.orderDetail?.deliveryList?.count)! > 0 {
            self.sections.append("DELIVERY")
            self.tableView.backgroundColor = #colorLiteral(red: 0.9529411765, green: 0.9529411765, blue: 0.9529411765, alpha: 1)
        }
        self.tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "orderDeliverySegue" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let destination = segue.destination as! OrderDetailController
                destination.orderId = self.orderDetail?.number!
                destination.orderDetail = self.orderDetail
                destination.delivery = self.orderDetail?.deliveryList![indexPath.row]
            }
        }
        if segue.identifier == "orderPendingDrugSegue" {
            let destination = segue.destination as! OrderPendingDrugController
            destination.orderId = self.orderDetail?.number!
            destination.orderDetail = self.orderDetail
        }
        if segue.identifier == "coordinationAddressSegue" {
            let destination = segue.destination as! CoordinationAddressController
            destination.orderDetail = self.orderDetail
        }
    }
}


extension OrderDeliveryMultipleController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.orderDetail == nil) ? 0 : self.sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch self.sections[section] {
            case "COORDINATION":
                return self.orderDetail?.drugsToDeliverList?.count ?? 0
            case "PENDING":
                return 1
            case "DELIVERY":
                return self.orderDetail?.deliveryList?.count ?? 0
            default:
                return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch self.sections[indexPath.section] {
            case "COORDINATION":
                let cellIdentifier = "orderDrugCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDrugCell
                let drug = (self.orderDetail?.drugsToDeliverList![indexPath.row])!
                cell?.amount.text = String(describing: drug.amount!)
                cell?.name.text = drug.name
                cell?.laboratory.text = drug.laboratory
                return cell!
            case "PENDING":
                let cellIdentifier = "orderPendingDrugCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDeliveryMultipleCell
                cell?.message.text = "\((SesionManager.getActiveUser()?.firstName)!), su pedido tendrá entregas parciales que debemos coordinar."
                return cell!
            default:
                let cellIdentifier = "orderDeliveryMultipleCell"
                let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? OrderDeliveryMultipleCell
                let delivery = (self.orderDetail?.deliveryList![indexPath.row])!
                cell?.icon.image = UIImage(named: UIConstant.instance.deliveryImageFor(statusCode: delivery.statusCode!))
                cell?.number.text = String(describing: delivery.number!)
                cell?.status.text = delivery.status!.uppercased()
                cell?.date.text = delivery.date!
                return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch self.sections[section] {
            case "COORDINATION":
                let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 60))
                let label = UILabel(frame: CGRect(x: 15, y: 30, width: view.frame.size.width-30, height: 30))
                returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                returnedView.addSubview(label)
                label.font = UIFont(name: "Roboto-Medium", size: 14.0)
                label.text = "MEDICAMENTOS"
                label.adjustsFontSizeToFitWidth = true
                label.minimumScaleFactor = 0.5
                label.textColor = #colorLiteral(red: 0, green: 0, blue: 0.1490196078, alpha: 1)
                return returnedView
            default:
                return nil
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        switch self.sections[section] {
            case "COORDINATION":
                let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 80))
                let button = UIButton(frame: CGRect(x: view.frame.size.width-205, y: 20, width: 190, height: 40))
                button.setTitle("COORDINAR ENTREGA", for: .normal)
                returnedView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                returnedView.addSubview(button)
                button.titleLabel?.font = UIFont(name: "Roboto-Medium", size: 15.0)
                button.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
                button.backgroundColor = #colorLiteral(red: 0, green: 0.6745098039, blue: 0.7921568627, alpha: 1)
                button.addTarget(self, action: #selector(coordinateDelivery), for: .touchUpInside)
                return returnedView
            default:
                return nil
        }
    }
    
    @objc func coordinateDelivery(button: UIButton) {
        self.performSegue(withIdentifier: "coordinationAddressSegue", sender: self)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch self.sections[section] {
            case "COORDINATION":
                return 60.0
            default:
                return 0.1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch self.sections[indexPath.section] {
            case "COORDINATION":
                return 60.0
            case "PENDING":
                return 65.0
            default:
                return 116.0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        switch self.sections[section] {
            case "COORDINATION":
                return 80.0
            default:
                return 0.1
        }
    }
}
