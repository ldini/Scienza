//
//  preguntasFrecuentes.swift
//  Scienza
//
//  Created by Kender on 2/6/17.
//  Copyright © 2017 fusap. All rights reserved.
//
import Foundation
import UIKit
import WebKit
import SVProgressHUD


class FAQController: UIViewController, WKNavigationDelegate {
    
    @IBOutlet var containerView: UIView!
    
    var webView: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.createWebView()
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func createWebView() {
        let frame = self.containerView.frame
        self.webView = WKWebView(
            frame: CGRect(x:0, y:0, width: frame.width, height: frame.height)
        )
        self.containerView.addSubview(self.webView)
        self.webView.navigationDelegate = self
        self.webView.allowsBackForwardNavigationGestures = true
        self.webView.isOpaque = false
        self.webView.backgroundColor = UIColor.clear
        self.webView.scrollView.backgroundColor = UIColor.clear
        self.webView.scrollView.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: -5)
    }
    
    func populateModel() {
        SVProgressHUD.show()
        let url = NSURL(string: HttpRequest.instance.urlFAQ)
        let request = NSURLRequest(url: url! as URL)
        self.webView.load(request as URLRequest)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        SVProgressHUD.dismiss()
        let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
            self.populateModel()
        }))
        self.present(alert, animated: true, completion: nil)
    }
}
