//
//  Version.swift
//  Scienza
//
//  Created by Kender on 7/8/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit

class VersionController: UIViewController {
    
    @IBOutlet weak var version: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupNavigationBar()
        self.populateModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupNavigationBar()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        let versionApp = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
        self.version.text = "Versión " + versionApp
    }
    
    func setupNavigationBar() {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func back(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}
