//
//  DetallesTrazabilidad.swift
//  Scienza
//
//  Created by Kender on 20/4/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD


class TraceDetailController: UIViewController {
    
    
    @IBOutlet weak var product: UILabel!
    @IBOutlet weak var laboratory: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var traceDetail: TraceDetail!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
        self.populateModel()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func populateModel() {
        self.product.text = self.traceDetail.product
        self.laboratory.text = self.traceDetail.laboratory
    }
}


extension TraceDetailController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "traceDetailCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TraceDetailCell
        cell?.monodrug.text = self.traceDetail.monodrug
        cell?.batch.text = self.traceDetail.batch
        cell?.expirationDate.text = self.traceDetail.expirationDate
        cell?.provider.text = self.traceDetail.provider
        cell?.originReceipt.text = self.traceDetail.origin?.receipt
        cell?.originDateTime.text = self.traceDetail.origin?.dateTime
        cell?.gln.text = self.traceDetail.destination?.gln
        cell?.destination.text = self.traceDetail.destination?.destination
        cell?.orderNumber.text = String((self.traceDetail.destination?.orderNumber)!)
        cell?.destinationReceipt.text = self.traceDetail.destination?.receipt
        cell?.destinationDate.text = self.traceDetail.destination?.date
        cell?.client.text = self.traceDetail.destination?.client
        cell?.province.text = self.traceDetail.destination?.province
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 578.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}




