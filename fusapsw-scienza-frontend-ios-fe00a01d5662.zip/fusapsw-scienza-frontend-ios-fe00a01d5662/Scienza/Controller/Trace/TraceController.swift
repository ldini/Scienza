//
//  TraceController.swift
//  Scienza
//
//  Created by Kender on 19/4/17.
//  Copyright © 2017 fusap. All rights reserved.
//
import Foundation
import UIKit
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper


class TraceController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var traceDetail: TraceDetail!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? TraceCell
        cell?.code.text = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "traceDetailSegue" {
            let destination = segue.destination as! TraceDetailController
            destination.traceDetail = self.traceDetail
        }
    }
    
    @IBAction func btnDetailOfCode(_ sender: Any) {
        let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! TraceCell
        self.getTraceDetail(code: cell.code.text!, qrCode: nil)
    }
    
    @IBAction func btnDetailOfDataMatrix(_ sender: Any) {
        self.performSegue(withIdentifier: "traceDataMatrixSegue", sender: nil)
    }
    
    @IBAction func unwindDetailOfDataMatrix(segue: UIStoryboardSegue!) {
        let source = segue.source as! TraceDataMatrixController
        self.getTraceDetail(code: nil, qrCode: source.datamatrixCode)
    }
    
    func getTraceDetail(code: String?, qrCode: String?) {
        if(!self.validate(code, qrCode)) {
            return
        }
        
        let endpoint = String(format: Endpoint.traceDetail, code ?? "", qrCode ?? "")
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<TraceDetailResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code != 0 {
                    let alert = UIAlertController(title: "", message: data.header?.error, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in self.getTraceDetail(code: code, qrCode: qrCode)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    break
                }
                else {
                    self.traceDetail = data.body!
                    self.performSegue(withIdentifier: "traceDetailSegue", sender: nil)
                }
                break
            case .failure:
                let alert = UIAlertController(title: "", message: Messages.errorConexion, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                alert.addAction(UIAlertAction(title: "Reintentar", style: .default, handler: { action in
                    self.getTraceDetail(code: code, qrCode: qrCode)
                }))
                self.present(alert, animated: true, completion: nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
    
    func validate(_ code: String?, _ qrCode: String?) -> Bool {
        let code = code ?? ""
        let qrCode = qrCode ?? ""
        if(code.count == 0 && qrCode.count == 0) {
            let alert = UIAlertController(title: "", message: Messages.completeCamposOblig, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            return true
        }
        return false
    }
}


extension TraceController : UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "traceCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? TraceCell
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let height = (UIScreen.main.bounds.height - 60) * (1 - 0.1496)
        return height > 520 ? 520.0 : height
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
}
