//
//  Documentation.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/15/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class DocumentationImageRequest: Request {
    
    var fileName: String?
    var image: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.fileName <- map["fileName"]
        self.image <- map["image"]
    }
}


class DocumentationFileRequest: Request {
    
    var fileName: String?
    var file: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.fileName <- map["fileName"]
        self.file <- map["file"]
    }
}


class DocumentationResponse: Response {
    
    var body: Documentation?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class DocumentationImageResponse: Response {
    
    var body: DocumentationImage?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class DocumentationFileResponse: Response {
    
    var body: DocumentationFile?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Documentation: NSObject, Mappable {
    
    var imageList: [DocumentationImage]?
    var fileList: [DocumentationFile]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.imageList <- map["images"]
        self.fileList <- map["files"]
    }
}


class DocumentationImage: NSObject, Mappable {
    
    var id: Int?
    var smallImage: String?
    var image: String?
    var date: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idDocumentation"]
        self.smallImage <- map["smallImageURL"]
        self.image <- map["imageURL"]
        self.date <- map["dateCreation"]
    }
}


class DocumentationFile: NSObject, Mappable {
    
    var id: Int?
    var name: String?
    var file: String?
    var date: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idDocumentation"]
        self.name <- map["fileName"]
        self.file <- map["fileURL"]
        self.date <- map["dateCreation"]
    }
}
