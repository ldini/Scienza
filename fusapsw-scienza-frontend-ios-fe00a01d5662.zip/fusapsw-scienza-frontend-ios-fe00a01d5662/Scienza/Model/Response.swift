//
//  Response.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper

class Response: NSObject, Mappable {
    
    var header: Header?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.header <- map["header"]
    }
}
