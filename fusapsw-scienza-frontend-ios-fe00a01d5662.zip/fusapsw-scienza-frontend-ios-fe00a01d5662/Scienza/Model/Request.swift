//
//  Request.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/17/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper

class Request: NSObject, Mappable {
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {}
}
