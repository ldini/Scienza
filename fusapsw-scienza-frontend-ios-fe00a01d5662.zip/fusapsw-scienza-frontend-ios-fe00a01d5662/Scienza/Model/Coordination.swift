//
//  Coordination.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/1/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class CoordinationRequest: Request {

    var orderId: Int?
    var proposalId: Int?
    var accepted: Bool?
    var changePharmacy: Bool?
    var addressCode: Int?
    var dateCode: String?
    var shiftCode: String?
    var paymentCode: String?
    var rejectComment: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.orderId <- map["orderId"]
        self.proposalId <- map["proposalId"]
        self.accepted <- map["accepted"]
        self.changePharmacy <- map["changePharmacy"]
        self.addressCode <- map["addressCode"]
        self.dateCode <- map["dateCode"]
        self.shiftCode <- map["shiftCode"]
        self.paymentCode <- map["paymentCode"]
        self.rejectComment <- map["rejectComment"]
    }
}


class CoordinationResponse: Response {
    
    var body: Coordination?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Coordination: NSObject, Mappable {
    
    var proposalId: Int?
    var payment: Float?
    var drugList: [Drug]?
    var proposalList: [ProposalAddress]?
    var paymentList: [ProposalPayment]?
    var showDrugs: Bool = false
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.proposalId <- map["proposalId"]
        self.payment <- map["payment"]
        self.drugList <- map["drugs"]
        self.proposalList <- map["proposalList"]
        self.paymentList <- map["paymentMethods"]
    }
    
    func rows() -> [Drug] {
        var rows: [Drug] = []
        if self.showDrugs {
            rows = self.drugList!
        }
        return rows
    }
    
    func hasPayment() -> Bool {
        return (self.payment ?? Float(0)) > Float(0)
    }
}


class ProposalAddress: NSObject, Mappable {
    
    var type: String?
    var addressText: String?
    var addressCode: Int?
    var pharmacy: String?
    var address: String?
    var dateList: [ProposalDate]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.type <- map["type"]
        self.addressText <- map["addressText"]
        self.addressCode <- map["addressCode"]
        self.pharmacy <- map["pharmacy"]
        self.address <- map["address"]
        self.dateList <- map["dateList"]
    }
}


class ProposalDate: NSObject, Mappable {
    
    var dateText: String?
    var dateCode: String?
    var shiftText: String?
    var shiftCode: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.dateText <- map["dateText"]
        self.dateCode <- map["dateCode"]
        self.shiftText <- map["shiftText"]
        self.shiftCode <- map["shiftCode"]
    }
}


class ProposalPayment: NSObject, Mappable {
    
    var paymentText: String?
    var paymentCode: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.paymentText <- map["paymentText"]
        self.paymentCode <- map["paymentCode"]
    }
}


class CoordinationPharmacyResponse: Response {
    
    var body: [ProposalPharmacy]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class ProposalPharmacy: NSObject, Mappable {
    
    var id: String?
    var preferred: Bool?
    var name: String?
    var address: String?
    var details: [String]?
    var latitude: Float?
    var longitude: Float?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idPharmacy"]
        self.preferred <- map["preferedPharmacy"]
        self.name <- map["name"]
        self.address <- map["address"]
        self.details <- map["texts"]
        self.latitude <- map["latitude"]
        self.longitude <- map["longitude"]
    }
}
