//
//  Order.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/22/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class OrderResponse: Response {
    
    var body: [Order]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class OrderDetailResponse: Response {
    
    var body: OrderDetail?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class OrderLocationResponse: Response {
    
    var body: Location?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Order: NSObject, Mappable {
    
    var id: Int?
    var type: String?
    var status: String?
    var statusCode: String?
    var orderNumber: Int?
    var deliveryDate: String?
    var partial: Bool?
    var coordinable: Bool?
    var allowUploads: Bool?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idOrder"]
        self.type <- map["type"]
        self.status <- map["status"]
        self.statusCode <- map["statusCode"]
        self.orderNumber <- map["orderNumber"]
        self.deliveryDate <- map["deliveryDate"]
        self.partial <- map["partial"]
        self.coordinable <- map["coordinable"]
        self.allowUploads <- map["allowUploads"]
    }
}


class OrderDetail: NSObject, Mappable {
    
    var id: Int?
    var type: String?
    var status: String?
    var statusCode: String?
    var number: Int?
    var date: String?
    var partialCoverageAmount: Float?
    var partial: Bool?
    var drugList: [Drug]?
    var drugsToDeliverList: [Drug]?
    var coordinable: Bool?
    var allowUploads: Bool?
    var deliveryList: [Delivery]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idOrder"]
        self.type <- map["type"]
        self.status <- map["status"]
        self.statusCode <- map["statusCode"]
        self.number <- map["orderNumber"]
        self.date <- map["orderDate"]
        self.partialCoverageAmount <- map["partialCoverageAmount"]
        self.partial <- map["partial"]
        self.drugList <- map["drugs"]
        self.drugsToDeliverList <- map["drugsToDeliver"]
        self.coordinable <- map["coordinable"]
        self.allowUploads <- map["allowUploads"]
        self.deliveryList <- map["deliveries"]
    }
}


class Drug: NSObject, Mappable {
    
    var name: String?
    var amount: Int?
    var laboratory: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.name <- map["name"]
        self.amount <- map["amount"]
        self.laboratory <- map["laboratory"]
    }
}


class Delivery: NSObject, Mappable {
    
    var number: Int?
    var address: String?
    var pharmacy: String?
    var date: String?
    var shift: String?
    var status: String?
    var statusCode: String?
    var paymentMethod: String?
    var payment: Float?
    var showLocation: Bool?
    var drugList: [DeliveryDrug]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.number <- map["deliveryNumber"]
        self.address <- map["deliveryAddress"]
        self.pharmacy <- map["deliveryPharmacy"]
        self.date <- map["deliveryDate"]
        self.shift <- map["deliveryShift"]
        self.status <- map["status"]
        self.statusCode <- map["statusCode"]
        self.paymentMethod <- map["paymentMethod"]
        self.payment <- map["payment"]
        self.showLocation <- map["showLocation"]
        self.drugList <- map["drugs"]
    }
}


class DeliveryDrug: NSObject, Mappable {
    
    var name: String?
    var amount: Int?
    var monodrug: String?
    var laboratory: String?
    var batch: String?
    var expirationDate: String?
    var traceList: [String]?
    var showDetail: Bool = false
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.name <- map["name"]
        self.amount <- map["amount"]
        self.monodrug <- map["monodrug"]
        self.laboratory <- map["laboratory"]
        self.batch <- map["batch"]
        self.expirationDate <- map["expirationDate"]
        self.traceList <- map["traces"]
    }
    
    func rows() -> [(label: String, value: String)] {
        var rows: [(label: String, value: String)] = []
        var traceIndex: Int = 1
        if self.showDetail {
            if self.monodrug != nil {
                rows.append((label: "MONODROGA", value: self.monodrug!))
            }
            if self.batch != nil {
                rows.append((label: "LOTE", value: self.batch!))
            }
            if self.expirationDate != nil {
                rows.append((label: "VENCIMIENTO", value: self.expirationDate!))
            }
            for trace in self.traceList! {
                rows.append((label: "TRAZA \(traceIndex)", value: trace))
                traceIndex += 1
            }
        }
        return rows
    }
}


class Location: NSObject, Mappable {
    
    var orderNumber: Int?
    var deliveryNumber: Int?
    var distributor: String?
    var patent: String?
    var arrivalTime: String?
    var distance: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.orderNumber <- map["orderNumber"]
        self.deliveryNumber <- map["deliveryNumber"]
        self.distributor <- map["distributor"]
        self.patent <- map["patent"]
        self.arrivalTime <- map["arrivalTime"]
        self.distance <- map["distance"]
    }
}
