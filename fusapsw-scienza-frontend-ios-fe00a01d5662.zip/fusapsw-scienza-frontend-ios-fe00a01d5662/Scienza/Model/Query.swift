//
//  Query.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/24/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class QueryResponse: Response {
    
    var body: [Query]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Query: NSObject, Mappable {
    
    var id: Int?
    var ticket: String?
    var queryType: String?
    var categoryType: String?
    var unreadMessages: Int?
    var lastMessageDate: String?
    var lastMessage: String?
    var closed: Bool?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idQuery"]
        self.ticket <- map["ticket"]
        self.queryType <- map["queryType"]
        self.categoryType <- map["categoryType"]
        self.unreadMessages <- map["unreadMessages"]
        self.lastMessageDate <- map["lastMessageDate"]
        self.lastMessage <- map["lastMessage"]
        self.closed <- map["closed"]
    }
}


class QueryDetailResponse: Response {
    
    var body: QueryDetail?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class QueryDetail: NSObject, Mappable {
    
    var id: Int?
    var publishKey: String?
    var subscribeKey: String?
    var channel: String?
    var ticket: String?
    var toolbarDescription: String?
    var footerDescription: String?
    var finished: Bool?
    var messages: [QueryMessage]?
    
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idQuery"]
        self.publishKey <- map["publishKey"]
        self.subscribeKey <- map["subscribeKey"]
        self.channel <- map["channel"]
        self.ticket <- map["ticket"]
        self.toolbarDescription <- map["toolbarDescription"]
        self.footerDescription <- map["footerDescription"]
        self.messages <- map["messages"]
        self.finished <- map["finished"]
    }
}


class QueryMessage: NSObject, Mappable {
    
    var from: String?
    var message: String?
    var date: String?
    
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.from <- map["from"]
        self.message <- map["message"]
        self.date <- map["date"]
    }
}


class QueryCreateRequest: Request {
    
    var id: Int?
    var desc: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.id <- map["idCategoryType"]
        self.desc <- map["description"]
    }
}


class QueryCreateResponse: Response {
    
    var body: QueryCreate?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class QueryCreate: NSObject, Mappable {
    
    var id: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idQuery"]
    }
}


class QueryDeleteRequest: Request {
    
    var idQuery: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.idQuery <- map["idQuery"]
    }
}
