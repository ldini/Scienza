//
//  Configuration.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/25/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import SVProgressHUD
import Alamofire
import AlamofireObjectMapper
import ObjectMapper
import RealmSwift


class Configuration : Object, Mappable {
    
    @objc dynamic var id: String = "CONFIG"
    @objc dynamic var token: String = ""
    @objc dynamic var role: String = ""
    @objc dynamic var user: User? = nil
    var relatedUsers = List<User>()
    
    override public class func primaryKey() -> String? {
        return "id"
    }
    
    override public class func indexedProperties() -> [String] {
        return []
    }
    
    override public class func ignoredProperties() -> [String] {
        return []
    }
    
    required convenience init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["id"]
        self.token <- map["token"]
        self.role <- map["role"]
        self.user <- map["user"]
        self.relatedUsers <- map["relatedUsers"]
    }
}


class User : Object, Mappable {
    
    @objc dynamic var avatar: String = ""
    @objc dynamic var firstName: String = ""
    @objc dynamic var lastName: String = ""
    @objc dynamic var documentNumber: Int = 0
    @objc dynamic var sapId: Int = 0
    @objc dynamic var verifyProfile: Bool = true
    var home: Home?
    
    override public class func primaryKey() -> String? {
        return "sapId"
    }
    
    override public class func indexedProperties() -> [String] {
        return []
    }
    
    override public class func ignoredProperties() -> [String] {
        return ["home"]
    }
    
    required convenience init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.avatar <- map["avatar"]
        self.firstName <- map["firstName"]
        self.lastName <- map["lastName"]
        self.documentNumber <- map["documentNumber"]
        self.sapId <- map["sapId"]
        self.verifyProfile <- map["verifyProfile"]
    }
    
    func avatarAsImage() -> UIImage {
        switch avatar {
            case "GIRL":
                return #imageLiteral(resourceName: "profile_girl")
            case "BOY":
                return #imageLiteral(resourceName: "profile_boy")
            case "WOMAN":
                return #imageLiteral(resourceName: "profile_woman")
            default:
                return #imageLiteral(resourceName: "profile_man")
        }
    }
    
    func home(completion: @escaping (_ result: Home?)->()) {
        SVProgressHUD.show()
        let endpoint = Endpoint.home
        let request = HttpRequest.instance.createGetRequest(endpoint: endpoint)
        AF.request(request).responseObject { (response: DataResponse<HomeResponse>) in
            switch response.result {
            case let .success(data):
                if data.header?.code == 0 {
                    self.home = data.body!
                    completion(self.home)
                }
                break
            case .failure:
                completion(nil)
                break
            }
            SVProgressHUD.dismiss()
        }
    }
}
