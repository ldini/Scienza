//
//  Header.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper

class Header: NSObject, Mappable {
    
    var code: Int?
    var error: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.code <- map["code"]
        self.error <- map["error"]
    }
}
