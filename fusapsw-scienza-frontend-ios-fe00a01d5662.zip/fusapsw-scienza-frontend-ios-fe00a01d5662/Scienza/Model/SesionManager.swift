//
//  SesionManager.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/16/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import RealmSwift


class SesionManager {
    
    private static var instance: SesionManager!
    private var configuration: Configuration?
    private var activeUser: User?
    
    
    public static func isOpen() -> Bool {
        return getInstance().configuration != nil
    }
    
    public static func createSession(configuration: Configuration) {
        getInstance().configuration = configuration
        getInstance().activeUser = configuration.user
        getInstance().persistConfig()
    }
    
    public static func closeSession() {
        getInstance().removeConfig()
    }
    
    public static func getConfiguration() -> Configuration? {
        return getInstance().configuration
    }
    
    public static func getToken() -> String? {
        return getInstance().configuration?.token
    }

    public static func getActiveUser() -> User? {
        return getInstance().activeUser
    }
    
    public static func addUser(user: User) {
        getInstance().persistUser(user: user)
    }
    
    public static func removeUser(user: User) {
        getInstance().removeUser(user: user)
    }
    
    public static func changeUser(user: User) {
        getInstance().activeUser = user
    }
    
    public static func getUsers() -> [User] {
        let config = getInstance().configuration!
        var users: [User] = []
        users.append(config.user!)
        for user in config.relatedUsers.toArray(ofType: User.self) {
            users.append(user)
        }
        return users
    }
    
    private static func getInstance() -> SesionManager {
        if instance == nil {
            instance = SesionManager()
        }
        return instance
    }
    
    private init() {
        self.retrieveConfig()
    }

    private func persistConfig() {
        do {
            let realm = try Realm()
            try realm.write {
                realm.add(self.configuration!, update: .all)
            }
        } catch {
            print("error REALM: \(error)")
        }
    }
    
    private func retrieveConfig() {
        do {
            let realm = try Realm()
            self.configuration = realm.object(ofType: Configuration.self, forPrimaryKey: "CONFIG")
            self.activeUser = self.configuration?.user
        } catch {
            print("error REALM: \(error)")
        }
    }
    
    private func removeConfig() {
        do {
            let realm = try Realm()
            try realm.write {
                realm.deleteAll()
            }
            self.configuration = nil
            self.activeUser = nil
        } catch {
            print("error REALM: \(error)")
        }
    }
    
    private func persistUser(user: User) {
        do {
            let realm = try Realm()
            try realm.write {
                realm.add(user, update: .all)
                self.configuration?.relatedUsers.append(user)
                realm.add(self.configuration!, update: .all)
            }
        } catch {
            print("error REALM: \(error)")
        }
    }
    
    private func removeUser(user: User) {
        do {
            let realm = try Realm()
            try realm.write {
                self.configuration?.relatedUsers.remove(at: (self.configuration?.relatedUsers.index(of: user))!)
                realm.add(self.configuration!, update: .all)
                realm.delete(user)
            }
        } catch {
            print("error REALM: \(error)")
        }
    }
}
