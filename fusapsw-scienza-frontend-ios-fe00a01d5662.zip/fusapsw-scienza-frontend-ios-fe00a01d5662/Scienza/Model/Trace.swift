//
//  Trace.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/30/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper

class TraceDetailResponse: Response {
    
    var body: TraceDetail?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class TraceDetail: NSObject, Mappable {
    
    var product: String?
    var laboratory: String?
    var monodrug: String?
    var batch: String?
    var expirationDate: String?
    var provider: String?
    var origin: TraceOrigin?
    var destination: TraceDestination?
    
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.product <- map["product"]
        self.laboratory <- map["laboratory"]
        self.monodrug <- map["monodrug"]
        self.batch <- map["batch"]
        self.expirationDate <- map["expirationDate"]
        self.provider <- map["provider"]
        self.origin <- map["origin"]
        self.destination <- map["destination"]
    }
}


class TraceOrigin: NSObject, Mappable {
    
    var receipt: String?
    var dateTime: String?
    
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.receipt <- map["receipt"]
        self.dateTime <- map["dateTime"]
    }
}


class TraceDestination: NSObject, Mappable {
    
    var gln: String?
    var destination: String?
    var orderNumber: Int?
    var receipt: String?
    var date: String?
    var client: String?
    var province: String?
    
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.gln <- map["gln"]
        self.destination <- map["destination"]
        self.orderNumber <- map["orderNumber"]
        self.receipt <- map["receipt"]
        self.date <- map["date"]
        self.client <- map["client"]
        self.province <- map["province"]
    }
}
