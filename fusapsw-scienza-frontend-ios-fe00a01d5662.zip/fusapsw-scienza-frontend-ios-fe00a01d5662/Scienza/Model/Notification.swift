//
//  Notification.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class NotificationResponse: Response {
    
    var body: [Notification]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class NotificationDetailResponse: Response {
    
    var body: NotificationDetail?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Notification: NSObject, Mappable {
    
    var id: Int?
    var title: String?
    var message: String?
    var date: String?
    var new: Bool?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idNotification"]
        self.title <- map["title"]
        self.message <- map["message"]
        self.date <- map["dateNotification"]
        self.new <- map["new"]
    }
}


class NotificationDetail: NSObject, Mappable {
    
    var id: Int?
    var title: String?
    var message: String?
    var date: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["idNotification"]
        self.title <- map["title"]
        self.message <- map["message"]
        self.date <- map["dateNotification"]
    }
}


class NotificationDeleteRequest: Request {
    
    var idNotification: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.idNotification <- map["idNotification"]
    }
}
