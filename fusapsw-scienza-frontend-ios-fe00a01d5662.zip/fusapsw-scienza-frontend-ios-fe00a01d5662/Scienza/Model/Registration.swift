//
//  Registration.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/25/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class LoginRequest: Request {
    
    var userName: String?
    var password: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.userName <- map["userName"]
        self.password <- map["password"]
    }
}


class LoginResponse: Response {
    
    var body: Configuration?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class RegistrationRequest: Request {
    
    var documentNumber: Int?
    var sapId: Int?
    var password: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.documentNumber <- map["documentNumber"]
        self.sapId <- map["sapId"]
        self.password <- map["password"]
    }
}


class RegistrationResponse: Response {
    
    var body: Configuration?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class RegistrationErrorRequest: Request {
    
    var documentNumber: Int?
    var sapId: Int?
    var password: String?
    var firstName: String?
    var lastName: String?
    var telephone: String?
    var email: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.documentNumber <- map["documentNumber"]
        self.sapId <- map["sapId"]
        self.password <- map["password"]
        self.firstName <- map["firstName"]
        self.lastName <- map["lastName"]
        self.telephone <- map["telephone"]
        self.email <- map["email"]
    }
}


class RegistrationErrorResponse: Response {
    
    var body: RegistrationError?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class RegistrationError: NSObject, Mappable {
    
    var message: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.message <- map["message"]
    }
}


class RecoverPasswordRequest: Request {
    
    var documentNumber: Int?
    var sapId: Int?
    var password: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.documentNumber <- map["documentNumber"]
        self.sapId <- map["sapId"]
        self.password <- map["password"]
    }
}


class RecoverPasswordResponse: Response {
    
    var body: Configuration?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class HomeResponse: Response {
    
    var body: Home?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Home: NSObject, Mappable {
    
    var pendingCoordination: Bool?
    var unreadNotifications: Int?
    var unreadQueries: Int?
    var allowUploadDocumentation: Bool?
    var prescriptionsUploaded: Int?
    var otherStudiesUploaded: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.pendingCoordination <- map["pendingCoordination"]
        self.unreadNotifications <- map["unreadNotifications"]
        self.unreadQueries <- map["unreadQueries"]
        self.allowUploadDocumentation <- map["allowUploadDocumentation"]
        self.prescriptionsUploaded <- map["prescriptionsUploaded"]
        self.otherStudiesUploaded <- map["otherStudiesUploaded"]
    }
}


class ProfileResponse: Response {
    
    var body: Profile?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class Profile: NSObject, Mappable {
    
    var pendingVerifyAdmin: Bool?
    var firstName: String?
    var lastName: String?
    var acronym: String?
    var healthInsurance: String?
    var documentNumber: Int?
    var gender: String?
    var birthdate: String?
    var province: String?
    var locality: String?
    var street: String?
    var streetNumber: Int?
    var floor: String?
    var department: String?
    var postalCode: String?
    var latitude: String?
    var longitude: String?
    var personalPhoneCode: String?
    var personalPhone: String?
    var workPhoneCode: String?
    var workPhone: String?
    var cellPhoneCode: String?
    var cellPhone: String?
    var cellCompanyCode: String?
    var email: String?

    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.pendingVerifyAdmin <- map["pendingVerifyAdmin"]
        self.firstName <- map["firstName"]
        self.lastName <- map["lastName"]
        self.acronym <- map["acronym"]
        self.healthInsurance <- map["healthInsurance"]
        self.documentNumber <- map["documentNumber"]
        self.gender <- map["gender"]
        self.birthdate <- map["birthdate"]
        self.province <- map["province"]
        self.locality <- map["locality"]
        self.street <- map["street"]
        self.streetNumber <- map["streetNumber"]
        self.floor <- map["floor"]
        self.department <- map["department"]
        self.postalCode <- map["postalCode"]
        self.latitude <- map["latitude"]
        self.longitude <- map["longitude"]
        self.personalPhoneCode <- map["personalPhoneCode"]
        self.personalPhone <- map["personalPhone"]
        self.workPhoneCode <- map["workPhoneCode"]
        self.workPhone <- map["workPhone"]
        self.cellPhoneCode <- map["cellPhoneCode"]
        self.cellPhone <- map["cellPhone"]
        self.cellCompanyCode <- map["cellCompanyCode"]
        self.email <- map["email"]
    }
}


class ProfileEditRequest: Request {
    
    var firstName: String?
    var lastName: String?
    var acronym: String?
    var gender: String?
    var birthdate: String?
    var province: String?
    var locality: String?
    var street: String?
    var streetNumber: Int?
    var floor: String?
    var department: String?
    var postalCode: String?
    var latitude: String?
    var longitude: String?
    var personalPhoneCode: String?
    var personalPhone: String?
    var workPhoneCode: String?
    var workPhone: String?
    var cellPhoneCode: String?
    var cellPhone: String?
    var cellCompanyCode: String?
    var email: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.firstName <- map["firstName"]
        self.lastName <- map["lastName"]
        self.acronym <- map["acronym"]
        self.gender <- map["gender"]
        self.birthdate <- map["birthdate"]
        self.province <- map["province"]
        self.locality <- map["locality"]
        self.street <- map["street"]
        self.streetNumber <- map["streetNumber"]
        self.floor <- map["floor"]
        self.department <- map["department"]
        self.postalCode <- map["postalCode"]
        self.latitude <- map["latitude"]
        self.longitude <- map["longitude"]
        self.personalPhoneCode <- map["personalPhoneCode"]
        self.personalPhone <- map["personalPhone"]
        self.workPhoneCode <- map["workPhoneCode"]
        self.workPhone <- map["workPhone"]
        self.cellPhoneCode <- map["cellPhoneCode"]
        self.cellPhone <- map["cellPhone"]
        self.cellCompanyCode <- map["cellCompanyCode"]
        self.email <- map["email"]
    }
}


class ProfileEditResponse: Response {
    
    var body: ProfileEdit?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class ProfileEdit: NSObject, Mappable {
    
    var pendingVerifyAdmin: Bool?
    var message: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.pendingVerifyAdmin <- map["pendingVerifyAdmin"]
        self.message <- map["message"]
    }
}


class BindAffiliateRequest: Request {
    
    var documentNumber: Int?
    var sapId: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.documentNumber <- map["documentNumber"]
        self.sapId <- map["sapId"]
    }
}


class BindAffiliateResponse: Response {
    
    var body: User?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class UnbindAffiliateRequest: Request {
    
    var sapId: Int?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.sapId <- map["sapId"]
    }
}


class OneSignalRequest: Request {
    
    var playerId: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        self.playerId <- map["playerId"]
    }
}
