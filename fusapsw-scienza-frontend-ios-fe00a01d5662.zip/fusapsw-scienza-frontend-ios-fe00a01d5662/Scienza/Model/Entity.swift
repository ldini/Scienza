//
//  Entity.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/22/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper


class CellCompanyResponse: Response {
    
    var body: [CellCompany]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class CellCompany: NSObject, Mappable {
    
    var code: String?
    var desc: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.code <- map["code"]
        self.desc <- map["description"]
    }
}


class QueryTypeResponse: Response {
    
    var body: [QueryType]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        self.body <- map["body"]
    }
}


class QueryType: NSObject, Mappable {
    
    var id: Int?
    var name: String?
    var categories: [CategoryType]?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["id"]
        self.name <- map["name"]
        self.categories <- map["categories"]
    }
}


class CategoryType: NSObject, Mappable {
    
    var id: Int?
    var name: String?
    
    override init() {
        super.init()
    }
    
    convenience required init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.id <- map["id"]
        self.name <- map["name"]
    }
}
