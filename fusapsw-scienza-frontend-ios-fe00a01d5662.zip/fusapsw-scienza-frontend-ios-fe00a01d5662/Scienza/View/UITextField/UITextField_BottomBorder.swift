//
//  estilos.swift
//  Scienza
//
//  Created by Kender on 31/1/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit


class UITextField_BottomBorder: UITextField {
    
    let border = CALayer()
    let width = CGFloat(2.0)
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.borderStyle = .none
        self.layer.backgroundColor = UIColor.white.cgColor
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.lightGray.cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
    
    override func becomeFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.blue.cgColor
        super.becomeFirstResponder()
        return true
    }
    
    override func resignFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.lightGray.cgColor
        super.resignFirstResponder()
        return true
    }
}


class UITextFieldGray_BottomBorder: UITextField {
    
    let border = CALayer()
    let width = CGFloat(2.0)
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.borderStyle = .none
        self.layer.backgroundColor = #colorLiteral(red: 0.9528577924, green: 0.9529945254, blue: 0.9528279901, alpha: 1)
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.lightGray.cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
    
    override func becomeFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.blue.cgColor
        super.becomeFirstResponder()
        return true
    }
    
    override func resignFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.lightGray.cgColor
        super.resignFirstResponder()
        return true
    }
}


