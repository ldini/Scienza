//
//  UITextView_BottomBorder.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/6/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit


class UITextView_BottomBorder: UITextView {
    
    let border = CALayer()
    let width = CGFloat(2.0)
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.border.style = .none
        self.layer.backgroundColor = UIColor.white.cgColor
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.lightGray.cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
    
    override func becomeFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.blue.cgColor
        super.becomeFirstResponder()
        return true
    }
    
    override func resignFirstResponder() -> Bool {
        self.layer.shadowColor = UIColor.lightGray.cgColor
        super.resignFirstResponder()
        return true
    }
}
