//
//  HomeView.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class HomeFunctionView: UIView {

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 0.3
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 8
    }
}
