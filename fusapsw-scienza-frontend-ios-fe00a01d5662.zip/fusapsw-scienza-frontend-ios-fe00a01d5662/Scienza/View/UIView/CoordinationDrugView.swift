//
//  CoordinationDrugView.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/1/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationDrugView: UITableViewHeaderFooterView {
    
    @IBOutlet var detailButton: UIButton!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

