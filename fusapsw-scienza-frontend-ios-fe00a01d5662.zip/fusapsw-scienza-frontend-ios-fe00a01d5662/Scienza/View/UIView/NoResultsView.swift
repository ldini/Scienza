//
//  NoResultsView.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/25/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit

class NoResultsView: UIView {
    
    @IBOutlet var view: UIView!
    @IBOutlet var message: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        Bundle.main.loadNibNamed("NoResultsView", owner: self, options: nil)
        self.addSubview(self.view)
        self.view.frame = self.bounds
        self.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    }
}

