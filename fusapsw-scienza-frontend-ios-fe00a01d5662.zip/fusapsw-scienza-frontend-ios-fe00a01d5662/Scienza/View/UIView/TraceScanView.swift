//
//  TraceView.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/25/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit

class TraceScanView: UIView {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 0.3
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 8
    }
}

