//
//  UIImageViewController.swift
//  Sanofi
//
//  Created by Franco Espinosa on 7/8/18.
//  Copyright © 2018 Sanofi. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView {
    
    func downloadFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else {
                    return
            }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    
    /* Descarga de imagenes con callback */
    func downloadFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit, completion: @escaping (_ result: Bool)->()) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else {
                    completion(false)
                    return
            }
            DispatchQueue.main.async() {
                self.image = image
                completion(true)
            }
            }.resume()
    }
    
    func downloadFrom(link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadFrom(url: url, contentMode: mode)
    }
    
    func downloadFrom(link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit, completion: @escaping (_ result: Bool)->()) {
        guard let url = URL(string: link) else { return }
        downloadFrom(url: url, contentMode: mode, completion: completion)
    }
}
