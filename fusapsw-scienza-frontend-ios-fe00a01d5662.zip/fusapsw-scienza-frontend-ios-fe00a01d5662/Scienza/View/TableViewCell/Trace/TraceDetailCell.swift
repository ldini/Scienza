//
//  TraceDetailCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/30/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit


class TraceDetailCell: UITableViewCell {
    
    @IBOutlet weak var monodrug: UILabel!
    @IBOutlet weak var batch: UILabel!
    @IBOutlet weak var expirationDate: UILabel!
    @IBOutlet weak var provider: UILabel!
    
    @IBOutlet weak var originReceipt: UILabel!
    @IBOutlet weak var originDateTime: UILabel!
    
    @IBOutlet weak var gln: UILabel!
    @IBOutlet weak var destination: UILabel!
    @IBOutlet weak var orderNumber: UILabel!
    @IBOutlet weak var destinationReceipt: UILabel!
    @IBOutlet weak var destinationDate: UILabel!
    @IBOutlet weak var client: UILabel!
    @IBOutlet weak var province: UILabel!
    
}
