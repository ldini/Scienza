//
//  CoordinationLegendCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 6/18/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationLegendCell: UITableViewCell {

    @IBOutlet var message: UILabel!
    
}
