//
//  OrderDrugCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class OrderDrugCell: UITableViewCell {

    @IBOutlet var amount: UILabel!
    @IBOutlet var name: UILabel!
    @IBOutlet var laboratory: UILabel!
    
}
