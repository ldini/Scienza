//
//  CoordinationFooterCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/5/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationSegueCell: UITableViewCell {

    @IBOutlet var message: UILabel!
}
