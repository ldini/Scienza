//
//  CoordinationProgress.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/2/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationProgressCell: UITableViewCell {

    @IBOutlet var progress: UIImageView!
}
