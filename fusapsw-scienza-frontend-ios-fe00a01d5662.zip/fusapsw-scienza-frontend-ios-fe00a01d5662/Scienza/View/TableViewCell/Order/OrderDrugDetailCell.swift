//
//  OrderDrugDetailCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/27/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class OrderDrugDetailCell: UITableViewCell {
    
    @IBOutlet var label: UILabel!
    @IBOutlet var value: UILabel!
    
}
