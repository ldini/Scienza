//
//  OrderCoordinatedCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/28/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class OrderCoordinatedCell: UITableViewCell {
    
    @IBOutlet var icon: UIImageView!
    @IBOutlet var title: UILabel!
    @IBOutlet var subtitle: UILabel!
    
}
