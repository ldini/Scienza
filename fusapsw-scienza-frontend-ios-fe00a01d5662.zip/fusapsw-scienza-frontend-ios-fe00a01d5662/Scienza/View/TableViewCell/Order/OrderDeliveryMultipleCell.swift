//
//  OrderDeliveryMultipleCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/28/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class OrderDeliveryMultipleCell: UITableViewCell {
    
    @IBOutlet var icon: UIImageView!
    @IBOutlet var number: UILabel!
    @IBOutlet var status: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var message: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        // do-nothing
    }
}
