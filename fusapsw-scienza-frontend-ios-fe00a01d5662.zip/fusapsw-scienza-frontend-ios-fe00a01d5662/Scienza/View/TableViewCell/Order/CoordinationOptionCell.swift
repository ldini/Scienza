//
//  CoordinationOption.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/2/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationOptionCell: UITableViewCell {
    
    @IBOutlet var view: UIView!
    @IBOutlet var check: UIImageView!
    @IBOutlet var title: UILabel!
    @IBOutlet var subtitle: UILabel!
    @IBOutlet var subtitle2: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        if (selected) {
            self.check.image = UIImage(named: "option_selected")
            self.view.backgroundColor = #colorLiteral(red: 0, green: 0.6745098039, blue: 0.7764705882, alpha: 1)
            self.title?.textColor = UIColor.white
            self.subtitle?.textColor = UIColor.white
            self.subtitle2?.textColor = UIColor.white
        } else {
            self.check.image = UIImage(named: "option_unselected")
            self.view.backgroundColor = #colorLiteral(red: 0.9529411765, green: 0.9529411765, blue: 0.9529411765, alpha: 1)
            self.title?.textColor = UIColor.black
            self.subtitle?.textColor = UIColor.black
            self.subtitle2?.textColor = UIColor.black
        }
    }
}
