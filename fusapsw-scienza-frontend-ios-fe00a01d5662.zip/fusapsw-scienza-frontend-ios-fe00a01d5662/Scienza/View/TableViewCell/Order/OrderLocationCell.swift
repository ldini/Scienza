//
//  OrderLocationCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/28/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class OrderLocationCell: UITableViewCell {
    
    @IBOutlet var arrivalTime: UILabel!
    @IBOutlet var distance: UILabel!
    @IBOutlet var distributor: UILabel!
    @IBOutlet var patent: UILabel!
    
}
