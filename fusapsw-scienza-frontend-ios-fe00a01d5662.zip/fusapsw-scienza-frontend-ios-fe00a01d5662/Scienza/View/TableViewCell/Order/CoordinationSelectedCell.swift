//
//  CoordinationOptionSelectedCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/3/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationSelectedCell: UITableViewCell {
    
    @IBOutlet var icon: UIImageView!
    @IBOutlet var title: UILabel!
    @IBOutlet var subtitle: UILabel!
    @IBOutlet var subtitle2: UILabel!
    
}
