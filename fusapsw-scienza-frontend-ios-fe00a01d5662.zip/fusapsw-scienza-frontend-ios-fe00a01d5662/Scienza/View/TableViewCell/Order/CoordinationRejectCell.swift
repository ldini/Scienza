//
//  CoordinationRejectCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/3/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class CoordinationRejectCell: UITableViewCell {

    @IBOutlet var message: UILabel!
    @IBOutlet var rejectComment: UITextView!
    
}
