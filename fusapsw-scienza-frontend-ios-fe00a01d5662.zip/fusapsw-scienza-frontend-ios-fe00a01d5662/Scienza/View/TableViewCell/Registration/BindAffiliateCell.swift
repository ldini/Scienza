//
//  BindAffiliateCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/30/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class BindAffiliateCell: UITableViewCell {

    @IBOutlet var sapId: UITextField!    
    @IBOutlet var documentNumber: UITextField!
    @IBOutlet var btnBind: UIButton!
    
}
