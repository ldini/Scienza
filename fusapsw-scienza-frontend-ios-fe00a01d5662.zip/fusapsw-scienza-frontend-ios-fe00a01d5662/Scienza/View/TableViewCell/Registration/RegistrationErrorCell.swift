//
//  RegistrationErrorCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/25/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class RegistrationErrorCell: UITableViewCell {

    @IBOutlet var firstName: UITextField!
    @IBOutlet var lastName: UITextField!
    @IBOutlet var telephone: UITextField!
    @IBOutlet var email: UITextField!
    
}
