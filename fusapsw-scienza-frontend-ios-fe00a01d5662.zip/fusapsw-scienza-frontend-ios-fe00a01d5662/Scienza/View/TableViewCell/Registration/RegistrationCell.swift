//
//  RegistrationCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 11/25/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class RegistrationCell: UITableViewCell {

    @IBOutlet weak var documentNumber: UITextField!
    @IBOutlet weak var sapId: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var password2: UITextField!
    @IBOutlet weak var btnCheckTyC: UIButton!
    @IBOutlet weak var btnRegistrate: UIButton!
    
}
