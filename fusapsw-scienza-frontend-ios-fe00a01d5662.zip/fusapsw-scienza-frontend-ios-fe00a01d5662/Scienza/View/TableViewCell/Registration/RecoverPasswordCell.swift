//
//  RecoverPasswordCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/22/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class RecoverPasswordCell: UITableViewCell {

    @IBOutlet var sapId: UITextField!
    @IBOutlet var documentNumber: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var password2: UITextField!
}
