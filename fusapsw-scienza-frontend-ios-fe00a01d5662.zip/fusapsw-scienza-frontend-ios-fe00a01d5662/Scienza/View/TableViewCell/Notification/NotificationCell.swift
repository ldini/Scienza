//
//  NotificationCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class NotificationCell: UITableViewCell {
    
    @IBOutlet weak var lblFecha: UILabel!
    @IBOutlet weak var lblTitulo: UILabel!
    @IBOutlet weak var lblMensaje: UILabel!
    @IBOutlet weak var lblNotificacionNuevo: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        // do-nothing
    }
}
