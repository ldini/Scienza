//
//  QueryCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/24/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class QueryCell: UITableViewCell {

    @IBOutlet var ticket: UILabel!
    @IBOutlet var query: UILabel!
    @IBOutlet var category: UILabel!
    @IBOutlet var message: UILabel!
    @IBOutlet var dateTime: UILabel!
    @IBOutlet var unreadMessages: UILabel!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        // do-nothing
    }
}
