//
//  QueryFooterCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/26/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class QueryFooterCell: UITableViewCell {

    @IBOutlet var message: UILabel!
    
}
