//
//  QueryCreateCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/24/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class QueryCreateCell: UITableViewCell {

    @IBOutlet var queryType: UITextField!
    @IBOutlet var categoryType: UITextField!
    @IBOutlet var message: UITextView!
    @IBOutlet var messageCount: UILabel!
    
}
