//
//  MenuAddProfileCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/30/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class MenuAddProfileCell: UITableViewCell {
    
    @IBOutlet var cellView: UIView!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        // do-nothing
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        self.cellView.backgroundColor = #colorLiteral(red: 0.09411764706, green: 0.09411764706, blue: 0.09411764706, alpha: 1)
    }
}
