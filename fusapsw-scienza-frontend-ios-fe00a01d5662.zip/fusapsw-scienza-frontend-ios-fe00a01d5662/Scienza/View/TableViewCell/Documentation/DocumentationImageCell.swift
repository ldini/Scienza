//
//  DocumentationImageCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/16/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class DocumentationImageCell: UICollectionViewCell {
    
    @IBOutlet var image: UIImageView!
    @IBOutlet var date: UILabel!
    
}
