//
//  DocumentationPDFCell.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/15/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit

class DocumentationFileCell: UITableViewCell {
    
    @IBOutlet weak var fileIcon: UIImageView!
    @IBOutlet weak var fileName: UILabel!
    @IBOutlet weak var downloadIcon: UIImageView!
    
}
