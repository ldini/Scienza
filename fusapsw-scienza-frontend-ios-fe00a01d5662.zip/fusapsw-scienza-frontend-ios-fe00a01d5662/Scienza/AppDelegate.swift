//
//  AppDelegate.swift
//  Scienza
//
//  Created by fusap on 15/12/16.
//  Copyright (c) 2016 fusap. All rights reserved.
//

import UIKit
import OneSignal
import SideMenu
import PubNub
import IQKeyboardManagerSwift
import GoogleMaps
import GooglePlaces


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var pubNub: PubNub?
    var channels: [String]?
    var launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    static var environment = Bundle.main.object(forInfoDictionaryKey: "environment") as? String
    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        self.launchOptions = launchOptions
        IQKeyboardManager.shared.enable = true
        
        /* Migracion de Defaults a Realm */
        let defaults = UserDefaults.standard
        let migrated = defaults.value(forKey: "migrated") as? Bool ?? false
        if !migrated {
            let token = defaults.value(forKey: "TokenUsuario") as? String
            if token != nil {
                let configuration = Configuration()
                configuration.token = token!
                configuration.role = "AFILIA"
                
                configuration.user = User()
                configuration.user?.avatar = defaults.value(forKey: "valorAvatar") as! String
                configuration.user?.firstName = defaults.value(forKey: "nombreUsuarioRemarcar") as! String
                configuration.user?.lastName = defaults.value(forKey: "apellidoUsuarioRemarcar") as! String
                configuration.user?.documentNumber = defaults.value(forKey: "nroDniUser") as! Int
                configuration.user?.sapId = Int(defaults.value(forKey: "valorSapID") as! String)!
                configuration.user?.verifyProfile = false
                
                let userRelated = defaults.value(forKey: "datosAfiliados") as! Array<Any>
                for index in 0 ..< userRelated.count {
                    let user = User()
                    let dictionary = userRelated[index] as! NSDictionary
                    user.avatar = dictionary["avatar"] as! String
                    user.firstName = dictionary["firstName"] as! String
                    user.lastName = dictionary["lastName"] as! String
                    user.documentNumber = dictionary["documentNumber"] as! Int
                    user.sapId = dictionary["sapId"] as! Int
                    user.verifyProfile = dictionary["verifyProfile"] as! Bool
                }
                
                SesionManager.createSession(configuration: configuration)
            }
            defaults.setValue(true, forKey: "migrated")
            defaults.synchronize()
        }
        
        /* Realm */
        if SesionManager.isOpen() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let homeController = storyboard.instantiateViewController(withIdentifier: "HomeNavigation") as? UINavigationController
            self.window?.rootViewController = homeController
        }
        else {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let loginController = storyboard.instantiateViewController(withIdentifier: "LoginNavigation") as? UINavigationController
            self.window?.rootViewController = loginController
        }
        
        /* GoogleMaps */
        GMSServices.provideAPIKey(HttpRequest.instance.googleMapsId)
        GMSPlacesClient.provideAPIKey(HttpRequest.instance.googleMapsId)
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        self.channels = self.pubNub?.channels()
        self.pubNub?.unsubscribeFromAll()
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        self.pubNub?.subscribeToChannels(self.channels!, withPresence: true)
        NotificationCenter.default.post(name: NSNotification.Name("ReloadQueryChat"), object: nil)
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        NotificationCenter.default.post(name: NSNotification.Name("ReloadHome"), object: nil)
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        self.pubNub?.unsubscribeFromAll()
    }
}

