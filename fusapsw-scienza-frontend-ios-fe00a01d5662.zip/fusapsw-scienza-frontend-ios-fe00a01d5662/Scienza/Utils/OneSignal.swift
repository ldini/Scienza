//
//  OneSignal.swift
//  Scienza
//
//  Created by Paola Torrealba on 1/20/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit
import OneSignal


extension OneSignal {
    
    static var rootController: UIViewController!
    
    
    static var notificationReceivedBlock: OSHandleNotificationReceivedBlock = { notification in
        print("Received = \((notification!.payload.notificationID)!)")
        print("LaunchURL = \(notification?.payload.launchURL ?? "None")")
        let viewControllers = rootController.navigationController?.viewControllers
        if let homeController = viewControllers?.first(where: {$0.isKind(of: HomeController.self)}) as? HomeController {
            homeController.populateModel()
        }
        if let queryController = viewControllers?.first(where: {$0.isKind(of: QueryController.self)}) as? QueryController {
            queryController.populateModel()
        }
    }
    
    
    static var notificationActionBlock: OSHandleNotificationActionBlock = { result in
        
        let payload: OSNotificationPayload? = result?.notification.payload
        print("Message = \((payload!.body)!)")
        
        if let additionalData = result!.notification.payload!.additionalData {
            
            let type = additionalData["type"] as? String
            let id = additionalData["id"] as? Int
            let sapId = additionalData["sapId"] as? Int
            
            print("Type = \(type ?? String())")
            print("ID = \(id ?? -1)")
            print("SapId = \(sapId ?? -1)")
            
            if let sapId = sapId {
                if sapId > 0 {
                    let user = SesionManager.getUsers().first(where: { $0.sapId == sapId }) ?? nil
                    if user != nil {
                        SesionManager.changeUser(user: user!)
                    }
                }
            }
            if let type = type {
                if type == "PROFILE_ACCEPTED" || type == "PROFILE_REJECTED" || type == "MENSAJE_ADMIN" {
                    let viewControllers = rootController.navigationController?.viewControllers.filter{(x) -> Bool in
                        x.isKind(of: HomeController.self) || x.isKind(of: NotificationController.self)
                    }
                    rootController.navigationController?.setViewControllers(viewControllers!, animated: true)
                    
                    let storyboard = UIStoryboard(name: "Notification", bundle: nil)
                    let notificationController = storyboard.instantiateViewController(withIdentifier: "NotificationDetail") as? NotificationDetailController
                    notificationController?.notificationId = id
                    rootController.navigationController?.show(notificationController!, sender: nil)
                }
                if type == "DISTRIB_ENTREGA" || type == "CERCANIA_ENTREGA" {
                    let viewControllers = rootController.navigationController?.viewControllers.filter{(x) -> Bool in
                        x.isKind(of: HomeController.self) || x.isKind(of: OrderController.self)
                    }
                    rootController.navigationController?.setViewControllers(viewControllers!, animated: true)
                    
                    let storyboard = UIStoryboard(name: "Order", bundle: nil)
                    let orderController = storyboard.instantiateViewController(withIdentifier: "OrderDetail") as? OrderDetailController
                    orderController?.orderId = id
                    rootController.navigationController?.show(orderController!, sender: nil)
                }
                if type == "CONSULTA_ASIGNADA" || type == "RTA_CONSULTA_ADMIN" {
                    let viewControllers = rootController.navigationController?.viewControllers.filter{(x) -> Bool in
                        x.isKind(of: HomeController.self) || x.isKind(of: QueryController.self)
                    }
                    rootController.navigationController?.setViewControllers(viewControllers!, animated: true)
                    
                    let storyboard = UIStoryboard(name: "Query", bundle: nil)
                    let queryChatController = storyboard.instantiateViewController(withIdentifier: "QueryChat") as? QueryChatController
                    queryChatController?.queryId = id
                    rootController.navigationController?.show(queryChatController!, sender: nil)
                }
            }
        }
    }
}
