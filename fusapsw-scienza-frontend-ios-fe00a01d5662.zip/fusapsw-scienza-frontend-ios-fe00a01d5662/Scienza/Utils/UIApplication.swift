//
//  UIApplication.swift
//  Scienza
//
//  Created by Paola Torrealba on 12/21/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import UIKit
import SideMenu

extension UIApplication {
    
    static var loginAnimation: UIView.AnimationOptions = .transitionFlipFromRight
    static var logoutAnimation: UIView.AnimationOptions = .transitionCrossDissolve
    
    public static func setRootView(_ viewController: UINavigationController,
                                   options: UIView.AnimationOptions = .transitionFlipFromRight,
                                   animated: Bool = true,
                                   duration: TimeInterval = 0.5,
                                   completion: (() -> Void)? = nil) {
        
        let keyWindow = UIApplication.shared.windows.first { $0.isKeyWindow }
        
        UIView.transition(with: keyWindow!, duration: duration, options: options, animations: {
            let oldState = UIView.areAnimationsEnabled
            let keyWindow = UIApplication.shared.windows.first { $0.isKeyWindow }
            UIView.setAnimationsEnabled(false)
            keyWindow?.rootViewController = viewController
            UIView.setAnimationsEnabled(oldState)
        }, completion: { completed in })
    }
}
