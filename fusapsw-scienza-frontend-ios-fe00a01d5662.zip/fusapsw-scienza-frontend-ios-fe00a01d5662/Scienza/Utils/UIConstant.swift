//
//  UIConstant.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/17/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation

struct UIConstant {
    
    static var instance = UIConstant()
    
    var orderIcons: [String: String] = [:]
    var deliveryIcons: [String: String] = [:]
    
    // Documentation
    let uploadPrescription = "¿está seguro que desea enviar la receta?"
    let uploadOtherStudy = "¿está seguro que desea enviar el estudio?"
    
    init() {
        self.orderIcons["REVISION"] = "order_review"
        self.orderIcons["AUDITORIA"] = "order_audit"
        self.orderIcons["PARA_COORDINAR"] = "order_to_coordinate"
        self.orderIcons["COORDINADO"] = "order_coordinated"
        self.orderIcons["ENTREGA_PARCIAL"] = "order_coordinated_partial"
        self.orderIcons["ENTREGADO"] = "order_finished"
        
        self.deliveryIcons["EN_PREPARACION"] = "delivery_finished"
        self.deliveryIcons["EN_DISTRIBUCION"] = "delivery_distribution"
        self.deliveryIcons["ENTREGADO"] = "delivery_finished"
    }
    
    func orderImageFor(statusCode: String) -> String {
        return self.orderIcons[statusCode] ?? "order_default"
    }
    
    func deliveryImageFor(statusCode: String) -> String {
        return self.deliveryIcons[statusCode] ?? "delivery_default"
    }
}
