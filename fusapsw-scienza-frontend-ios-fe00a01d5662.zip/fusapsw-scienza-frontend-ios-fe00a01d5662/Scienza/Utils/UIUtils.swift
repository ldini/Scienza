//
//  UiUtils.swift
//  Scienza
//
//  Created by Matias M. Gonzalez on 7/11/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation
import UIKit


class Utils {
    static func displayDialog(title: String, message: String, okActionTitle: String? = nil, onOkHandler: ((UIAlertAction) -> Swift.Void)? = nil, cancelTitle: String? = nil, onCancelHandler: ((UIAlertAction) -> Swift.Void)? = nil, view: UIViewController){
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        if(okActionTitle != nil){
            if(onOkHandler != nil){
                alert.addAction(UIAlertAction(title: okActionTitle, style: UIAlertAction.Style.default, handler: onOkHandler))
            }
        }else{
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        }
        
        if(cancelTitle != nil){
            if(onCancelHandler != nil){
                alert.addAction(UIAlertAction(title: cancelTitle, style: UIAlertAction.Style.default, handler: onCancelHandler))
            }else{
                alert.addAction(UIAlertAction(title: cancelTitle, style: UIAlertAction.Style.default, handler: {action in }))
            }
        }
        
        view.present(alert, animated: true, completion: nil)
    }
}
