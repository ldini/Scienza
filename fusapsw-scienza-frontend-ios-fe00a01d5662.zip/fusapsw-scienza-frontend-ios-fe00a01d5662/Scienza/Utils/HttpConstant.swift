//
//  HttpConstant.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation

struct Endpoint {
    
    static let login = "/login"
    static let logout = "/logout"
    static let registration = "/registration"
    static let registrationError = "/registration/error"
    static let recoverPassword = "/password-recovery"
    static let home = "/home"
    static let profile = "/affiliateProfile/get"
    static let profileEdit = "/affiliateProfile/edit"
    static let bindAffiliate = "/bindAffiliate"
    static let unbindAffiliate = "/unbindAffiliate"
    static let updatePlayerId = "/updatePlayerId"
    
    static let cellCompany = "/entity/cellCompanyList"
    static let queryType = "/entity/queryTypeList"
    
    static let orderList = "/order/list"
    static let orderFromList = "/order/list?idOrder=%1$i"
    static let orderDetail = "/order/get?idOrder=%1$i"
    static let orderLocation = "/order/deliveryLocation?deliveryNumber=%1$i"
    
    static let coordination = "/order/coordination?idOrder=%1$i"
    static let coordinationPharmacy = "/order/pharmacySearch?idOrder=%1$i"
    static let coordinationResult = "/order/coordination"
    
    static let queryList = "/query/list"
    static let queryDetail = "/query/get?idQuery=%1$i"
    static let queryCreate = "/query/create"
    static let queryDelete = "/query/delete"
    
    static let traceDetail = "/trace/get?code=%1$@&QRcode=%2$@"
    
    static let notificationList = "/notification/list"
    static let notificationDetail = "/notification/get?idNotification=%1$i"
    static let notificationDelete = "/notification/delete"
    
    static let documentationPrescriptionList = "/documentation/prescription/list"
    static let documentationOtherStudyList = "/documentation/otherStudy/list"
    static let documentationPrescriptionImageCreate = "/documentation/prescription/image/create"
    static let documentationPrescriptionFileCreate = "/documentation/prescription/file/create"
    static let documentationOtherStudyImageCreate = "/documentation/otherStudy/image/create"
    static let documentationOtherStudyFileCreate = "/documentation/otherStudy/file/create"
}
