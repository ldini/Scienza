//
//  UIImage.swift
//  Scienza
//
//  Created by Paola Torrealba on 4/13/19.
//  Copyright © 2019 fusap. All rights reserved.
//

import Foundation
import UIKit

extension UIImage {
    
    func resizeTo(sizeChange:CGSize)-> UIImage{
        
        let hasAlpha = true
        let scale: CGFloat = 0.0 // Use scale factor of main screen
        
        UIGraphicsBeginImageContextWithOptions(sizeChange, !hasAlpha, scale)
        self.draw(in: CGRect(origin: CGPoint.zero, size: sizeChange))
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        return scaledImage!
    }
    
}
