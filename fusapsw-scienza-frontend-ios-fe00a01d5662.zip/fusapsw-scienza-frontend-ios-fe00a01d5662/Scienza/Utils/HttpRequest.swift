//
//  HttpRequest.swift
//  Scienza
//
//  Created by Paola Torrealba on 10/14/18.
//  Copyright © 2018 fusap. All rights reserved.
//

import Foundation
import ObjectMapper

class HttpRequest {
    
    static var instance = HttpRequest()
    
    var url = ""
    var appID = ""
    var deviceType = ""
    var contentType = ""
    var oneSignalId = ""
    var googleMapsId = ""
    var urlFAQ = ""
    var urlTYC = ""
    
    
    init() {
        if AppDelegate.environment == "local" {
            self.url = "http://localhost:8100/api"
            self.appID = "A9F67BF3-5B84-454E-B697-C006DF299F3E"
            self.deviceType = "IOS"
            self.contentType = "application/json; charset:UTF-8"
            self.oneSignalId = "8655056d-da67-48a0-9890-c64449549d64"
            self.googleMapsId = "AIzaSyAZ9vkN4Ey2JTT6BngHqjZvqjGh1WN3hjc"
            self.urlFAQ = "http://server.fusap.com.ar/Scienza/faq"
            self.urlTYC = "http://server.fusap.com.ar/Scienza/terms-and-conditions"
        }
        if AppDelegate.environment == "development" {
            self.url = "http://server.fusap.com.ar:8100/api"
            self.appID = "A9F67BF3-5B84-454E-B697-C006DF299F3E"
            self.deviceType = "IOS"
            self.contentType = "application/json; charset:UTF-8"
            self.oneSignalId = "8655056d-da67-48a0-9890-c64449549d64"
            self.googleMapsId = "AIzaSyAZ9vkN4Ey2JTT6BngHqjZvqjGh1WN3hjc"
            self.urlFAQ = "http://server.fusap.com.ar/Scienza/faq"
            self.urlTYC = "http://server.fusap.com.ar/Scienza/terms-and-conditions"
        }
        if AppDelegate.environment == "testing" {
            self.url = "http://afiback.scienza.com.ar:8100/api"
            self.appID = "BCC67F16-98AE-4B77-A636-B24A43237C06"
            self.deviceType = "IOS"
            self.contentType = "application/json; charset:UTF-8"
            self.oneSignalId = "5c209306-42b8-4e51-857e-3a7596848310"
            self.googleMapsId = "AIzaSyAZ9vkN4Ey2JTT6BngHqjZvqjGh1WN3hjc"
            self.urlFAQ = "http://afiweb.scienza.com.ar/Scienza/faq"
            self.urlTYC = "http://afiweb.scienza.com.ar/Scienza/terms-and-conditions"
        }
        if AppDelegate.environment == "production" {
            self.url = "http://appar.scienza.online:8100/api"
            self.appID = "C2676F7C-CD47-4EBF-80FF-8B7E38898B5E"
            self.deviceType = "IOS"
            self.contentType = "application/json; charset:UTF-8"
            self.oneSignalId = "1d88bc2d-7632-47ac-b4dd-8b3d265145f5"
            self.googleMapsId = "AIzaSyA8MgzI8m2-lsJwlxbIQDz4lbY4gpvaACo"
            self.urlFAQ = "http://appar.scienza.online/Scienza/faq"
            self.urlTYC = "http://appar.scienza.online/Scienza/terms-and-conditions"
        }
    }
    
    public func createGetRequest(endpoint: String) -> URLRequest{
        return createGetRequest(
            endpoint: endpoint,
            token: SesionManager.getToken() ?? "-1",
            user: SesionManager.getActiveUser()
        )
    }
    
    public func createGetRequest(endpoint: String, token: String, user: User?) -> URLRequest{
        var request = URLRequest(url: NSURL.init(string: self.url + endpoint)! as URL)
        let version = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
        request.httpMethod = "GET"
        request.setValue(self.appID, forHTTPHeaderField: "AppID")
        request.setValue(token, forHTTPHeaderField: "Token")
        request.setValue(self.deviceType, forHTTPHeaderField: "DeviceType")
        request.setValue(String(user?.sapId ?? -1), forHTTPHeaderField: "SapId")
        request.setValue(version, forHTTPHeaderField: "Version")
        request.setValue(self.contentType, forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 10
        return request
    }
    
    public func createPostRequest(endpoint: String, data: Request?) -> URLRequest{
        return self.createPostRequest(
            endpoint: endpoint,
            data: data,
            token: SesionManager.getToken() ?? "-1",
            user: SesionManager.getActiveUser(),
            timeout: nil
        )
    }
    
    public func createPostRequest(endpoint: String, data: Request?, timeout: TimeInterval?) -> URLRequest{
        return self.createPostRequest(
            endpoint: endpoint,
            data: data,
            token: SesionManager.getToken() ?? "-1",
            user: SesionManager.getActiveUser(),
            timeout: timeout
        )
    }
    
    public func createPostRequest(
        endpoint: String,
        data: Request?,
        token: String,
        user: User?,
        timeout: TimeInterval?
    ) -> URLRequest{
        var request = URLRequest(url: NSURL.init(string: self.url + endpoint)! as URL)
        let version = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
        request.httpMethod = "POST"
        request.setValue(self.appID, forHTTPHeaderField: "AppID")
        request.setValue(token, forHTTPHeaderField: "Token")
        request.setValue(self.deviceType, forHTTPHeaderField: "DeviceType")
        request.setValue(String(user?.sapId ?? -1), forHTTPHeaderField: "SapId")
        request.setValue(version, forHTTPHeaderField: "Version")
        request.setValue(self.contentType, forHTTPHeaderField: "Content-Type")
        if let data = data {
            let parameters = Mapper().toJSON(data)
            request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        }
        request.timeoutInterval = timeout ?? 10
        return request
    }
}
