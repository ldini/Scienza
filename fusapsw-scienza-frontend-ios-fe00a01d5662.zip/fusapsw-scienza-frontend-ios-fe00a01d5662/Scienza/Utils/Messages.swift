//
//  textos.swift
//  Scienza
//
//  Created by Kender on 17/5/17.
//  Copyright © 2017 fusap. All rights reserved.
//

import Foundation


struct Messages {

    static let proposalError = "Por favor, seleccione una opción."
    static let proposalRejectComment = "Por favor, complete el motivo de rechazo de la propuesta."
    
    //Errores
    static let errorConexion = "Hubo un error de conexión. Por favor Intente nuevamente"
    static let sinResultados = "No se encontraron resultados."
    static let clavesDistintas = "Las contraseñas no coinciden, intente nuevamente."
    static let completeCamposOblig = "Debe completar todos los campos."
    static let completePhoneOblig = "Debe indicar el código de área y el teléfono."
    static let completeCellPhoneOblig = "Debe indicar el código de área, el teléfono y compañía celular."
    static let aceptarTerminosCond = "Para poder continuar, usted debe aceptar los Términos y Condiciones."
    static let verificacionPendiente = "Ya existe una verificación pendiente, Scienza se comunicará a la brevedad."
    static let longitudDni = "La longitud del DNI es mayor a 8 caracteres."
    static let longitudSapID = "La longitud del Número de usuario es mayor a 8 caracteres."
    static let sinResultadosTrazas = "No se encontraron resultados relacionados con su búsqueda."
    static let sinNotificaciones = "Usted no tiene notificaciones pendientes."
    static let longitudClave = "La contraseña deberá contener al menos 6 caracteres."
    static let eliminarConsulta = "¿Desea eliminar esta solicitud?"
    static let eliminarNotificacion = "¿Desea eliminar esta notificación?"
}
